package ru.jcod.mobcatalog.net;

import java.io.ByteArrayInputStream;
import java.io.InputStreamReader;
import org.kxml2.io.KXmlParser;
import org.xmlpull.v1.XmlPullParser;
import ru.jcod.mobcatalog.Config;
import ru.jcod.mobcatalog.data.MyData;
import ru.jcod.mobcatalog.data.MyLocate;
import ru.jcod.mobcatalog.data.MyTable;
import ru.jcod.mobcatalog.ui.CG;
import ru.jcod.mobcatalog.ui.SCat;
import ru.jcod.mobcatalog.ui.SConnect;
import ru.jcod.mobcatalog.ui.SContent;
import ru.jcod.mobcatalog.ui.SFirst;
import ru.jcod.mobcatalog.ui.SLocate;
import ru.jcod.mobcatalog.ui.SNames;
import ru.jcod.mobcatalog.ui.SObiav;
import ru.jcod.mobcatalog.ui.SObiav_add;
import ru.jcod.mobcatalog.ui.SObiav_add_load;
import ru.jcod.mobcatalog.ui.SObiav_list;
import ru.jcod.mobcatalog.ui.SSubCat;
import ru.jcod.mobcatalog.ui.SVac;
import ru.jcod.mobcatalog.ui.ScreenCanvas;

public class Parser {

    public static Parser inst;
    private String temp1="";
    private String temp2="";
    private String stop_word="";
    private boolean process_data=false;

    public Parser(){
        inst=this;
    }

    public void pars(String otvet){
        process_data=true;
        stop_word=otvet.substring(otvet.lastIndexOf('/')-1);
        System.out.println(otvet+"\n tagword:"+stop_word);
        if (stop_word.equals("</rg_list>")) pars_rg(otvet);
            else if (stop_word.equals("</ray_list>")) pars_ray(otvet);
            else if (stop_word.equals("</punkt_list>")) pars_punkt(otvet);
            else if (stop_word.equals("</street_list>")) pars_street(otvet);
            else if (stop_word.equals("</cat_list>")) pars_cat(otvet);
            else if (stop_word.equals("</subcat_list>")) pars_subcat(otvet);
            else if (stop_word.equals("</names_list>")) pars_names(otvet);
            else if (stop_word.equals("</info_list>")) pars_info(otvet);
            else if (stop_word.equals("</prof_list>")) pars_prof(otvet);
            else if (stop_word.equals("</vac_list>")) pars_vac(otvet);
            else if (stop_word.equals("</vac_full>")) pars_vacfull(otvet);
            else if (stop_word.equals("</sec_list>")) pars_seclist(otvet);
            else if (stop_word.equals("</subsec_list>")) pars_subseclist(otvet);
            else if (stop_word.equals("</ann_list>")) pars_ann(otvet);
            else if (stop_word.equals("</ann_full>")) pars_annfull(otvet);
            else if (stop_word.equals("</hello_ok>")) pars_hello(otvet);
            else if (stop_word.equals("</ann_ok>")) pars_ann_add(otvet);
            else if (stop_word.equals("</alive_ok>")) pars_alive(otvet);
            else {

            }
        process_data=false;
    }

    public boolean process_data(){
        return process_data;
    }

    public String lspars(String s){
        int i=s.indexOf("&#34;");
        while(i!=-1){
            s=s.substring(0, i-1)+"\""+s.substring(i+5);
        }
        return s;
    }

    public void pars_rg(String s){
        try{
            KXmlParser parser=new KXmlParser();
            parser.setInput(new InputStreamReader(new ByteArrayInputStream(s.getBytes("UTF-8")),"UTF-8"));
            parser.nextTag();
            parser.require(XmlPullParser.START_TAG, null, "rg_list");
            while(parser.nextTag() == XmlPullParser.START_TAG) {
                parser.require(XmlPullParser.START_TAG, null, "reg");
                temp1=parser.getAttributeValue("","id");
                temp2=parser.getAttributeValue("","text");
                MyLocate.inst.addrg(temp1,temp2);
                parser.next();
                //parser.require(XmlPullParser.END_TAG, null, "reg");
            }
            //parser.require(XmlPullParser.END_TAG, null, "rg_list");
            SLocate.inst.loadlist(MyLocate.inst.get_v_rg_name());
        }catch(Exception e){}
    }

    public void pars_ray(String s){
        try{
            KXmlParser parser=new KXmlParser();
            parser.setInput(new InputStreamReader(new ByteArrayInputStream(s.getBytes("UTF-8")),"UTF-8"));
            parser.nextTag();
            parser.require(XmlPullParser.START_TAG, null, "ray_list");
            while(parser.nextTag() == XmlPullParser.START_TAG) {
                parser.require(XmlPullParser.START_TAG, null, "ray");
                temp1=parser.getAttributeValue("","id");
                temp2=parser.getAttributeValue("","text");
                MyLocate.inst.addray(temp1,temp2);
                parser.next();
                //parser.require(XmlPullParser.END_TAG, null, "ray");
            }
            //parser.require(XmlPullParser.END_TAG, null, "ray_list");
            SLocate.inst.loadlist(MyLocate.inst.get_v_ray_name());
        }catch(Exception e){}
    }

    public void pars_punkt(String s){
        try{
            KXmlParser parser=new KXmlParser();
            parser.setInput(new InputStreamReader(new ByteArrayInputStream(s.getBytes("UTF-8")),"UTF-8"));
            parser.nextTag();
            parser.require(XmlPullParser.START_TAG, null, "punkt_list");
            while(parser.nextTag() == XmlPullParser.START_TAG) {
                parser.require(XmlPullParser.START_TAG, null, "punkt");
                temp1=parser.getAttributeValue("","id");
                temp2=parser.getAttributeValue("","text");
                MyLocate.inst.addpunkt(temp1,temp2);
                parser.next();
                //parser.require(XmlPullParser.END_TAG, null, "punkt");
            }
            //parser.require(XmlPullParser.END_TAG, null, "punkt_list");
            SLocate.inst.loadlist(MyLocate.inst.get_v_punkt_name());
        }catch(Exception e){}
    }

    public void pars_street(String s){
        try{
            KXmlParser parser=new KXmlParser();
            parser.setInput(new InputStreamReader(new ByteArrayInputStream(s.getBytes("UTF-8")),"UTF-8"));
            parser.nextTag();
            parser.require(XmlPullParser.START_TAG, null, "street_list");
            while(parser.nextTag() == XmlPullParser.START_TAG) {
                parser.require(XmlPullParser.START_TAG, null, "street");
                temp1=parser.getAttributeValue("","id");
                temp2=parser.getAttributeValue("","text");
                MyLocate.inst.addstreet(temp1,temp2);
                parser.next();
                //parser.require(XmlPullParser.END_TAG, null, "street");
            }
            //parser.require(XmlPullParser.END_TAG, null, "street_list");
            SLocate.inst.loadlist(MyLocate.inst.get_v_street_name());
        }catch(Exception e){}
    }

    public void pars_cat(String s){
        try{
            KXmlParser parser=new KXmlParser();
            parser.setInput(new InputStreamReader(new ByteArrayInputStream(s.getBytes("UTF-8")),"UTF-8"));
            parser.nextTag();
            parser.require(XmlPullParser.START_TAG, null, "cat_list");
            while(parser.nextTag() == XmlPullParser.START_TAG) {
                parser.require(XmlPullParser.START_TAG, null, "cat");
                MyData.inst.table.add(lspars(parser.getAttributeValue("","id")),
                                      lspars(parser.getAttributeValue("","text")), null);
                parser.nextText();
                //parser.require(XmlPullParser.END_TAG, null, "cat");
            }
            //parser.require(XmlPullParser.END_TAG, null, "cat_list");
            SCat.inst.load_data(MyData.inst.table);
        }catch(Exception e){}
    }

    public void pars_subcat(String s){
        try{
            KXmlParser parser=new KXmlParser();
            parser.setInput(new InputStreamReader(new ByteArrayInputStream(s.getBytes("UTF-8")),"UTF-8"));
            parser.nextTag();
            parser.require(XmlPullParser.START_TAG, null, "subcat_list");
            while(parser.nextTag() == XmlPullParser.START_TAG) {
                parser.require(XmlPullParser.START_TAG, null, "sub");
                MyData.inst.get_table_subcat().add(lspars(parser.getAttributeValue("","id")),
                                                   lspars(parser.getAttributeValue("","text")), null);
                parser.nextText();
                //parser.require(XmlPullParser.END_TAG, null, "sub");
            }
            //parser.require(XmlPullParser.END_TAG, null, "subcat_list");
            SSubCat.inst.load_data(MyData.inst.get_table_subcat());
        }catch(Exception e){}
    }

    public void pars_names(String s){
        MyTable table;
        if (SNames.inst.search) table=MyData.inst.get_table_search();
            else table=MyData.inst.get_table_names();
        try{
            KXmlParser parser=new KXmlParser();
            parser.setInput(new InputStreamReader(new ByteArrayInputStream(s.getBytes("UTF-8")),"UTF-8"));
            parser.nextTag();
            parser.require(XmlPullParser.START_TAG, null, "names_list");
            //String page_id=parser.getAttributeValue("","page_id");
            table.table_prop1=Integer.parseInt(parser.getAttributeValue("","page_count"));
            while(parser.nextTag() == XmlPullParser.START_TAG) {
                parser.require(XmlPullParser.START_TAG, null, "name");
                table.add(lspars(parser.getAttributeValue("","id")),
                                                  lspars(parser.getAttributeValue("","text")), null);
                parser.nextText();
                //parser.require(XmlPullParser.END_TAG, null, "name");
            }
            //parser.require(XmlPullParser.END_TAG, null, "names_list");
            SNames.inst.load_data(table);
        }catch(Exception e){}
    }

    public void pars_info(String s){
       MyTable table;
       if (SNames.inst.search) table=new MyTable();
       else table=MyData.inst.get_table_info();
        try{
            KXmlParser parser=new KXmlParser();
            parser.setInput(new InputStreamReader(new ByteArrayInputStream(s.getBytes("UTF-8")),"UTF-8"));
            parser.nextTag();
            parser.require(XmlPullParser.START_TAG, null, "info_list");
            while(parser.nextTag() == XmlPullParser.START_TAG) {
                parser.require(XmlPullParser.START_TAG, null, "head");
                String head=lspars(parser.getAttributeValue("","text"));
                String logo_id=lspars(parser.getAttributeValue("","logo_id"));
                String data="";
                while(parser.nextTag() == XmlPullParser.START_TAG){
                    parser.require(XmlPullParser.START_TAG, null, "data");
                    data=data+lspars(parser.getAttributeValue("","text"))+'\n';
                    parser.nextText();
                    //parser.require(XmlPullParser.END_TAG, null, "data");
                }
                table.add(logo_id,head,data);
                //parser.require(XmlPullParser.END_TAG, null, "head");
            }
            //parser.require(XmlPullParser.END_TAG, null, "info_list");
            SContent.inst.load_data(table);
        }catch(Exception e){}
     }

    public void pars_prof(String s){
        MyData.inst.table_prof=new MyTable();
        MyTable table=MyData.inst.table_prof;
        try{
            KXmlParser parser=new KXmlParser();
            parser.setInput(new InputStreamReader(new ByteArrayInputStream(s.getBytes("UTF-8")),"UTF-8"));
            parser.nextTag();
            parser.require(XmlPullParser.START_TAG, null, "prof_list");
            while(parser.nextTag() == XmlPullParser.START_TAG) {
                parser.require(XmlPullParser.START_TAG, null, "prof");
                table.add(lspars(parser.getAttributeValue("","id")),
                                                   lspars(parser.getAttributeValue("","text")), null);
                parser.nextText();
                //parser.require(XmlPullParser.END_TAG, null, "prof");
            }
            //parser.require(XmlPullParser.END_TAG, null, "prof_list");
            SCat.inst.load_data(table);
        }catch(Exception e){}
     }

     public void pars_vac(String s){
        MyTable table;
        if (SVac.inst.search) table=MyData.inst.get_table_search();
        else table=MyData.inst.get_table_vac_list();
        try{
            KXmlParser parser=new KXmlParser();
            parser.setInput(new InputStreamReader(new ByteArrayInputStream(s.getBytes("UTF-8")),"UTF-8"));
            parser.nextTag();
            parser.require(XmlPullParser.START_TAG, null, "vac_list");
            //String page_id=parser.getAttributeValue("","page_id");
            table.table_prop1=Integer.parseInt(parser.getAttributeValue("","page_count"));
            while(parser.nextTag() == XmlPullParser.START_TAG) {
                parser.require(XmlPullParser.START_TAG, null, "vac");
                table.add(lspars(parser.getAttributeValue("","id")),
                                                  lspars(parser.getAttributeValue("","text")), null);
                parser.nextText();
                //parser.require(XmlPullParser.END_TAG, null, "vac");
            }
            //parser.require(XmlPullParser.END_TAG, null, "vac_list");
            SVac.inst.load_data(table);
        }catch(Exception e){}
    }

    public void pars_vacfull(String s){
       MyTable table;
       if (SVac.inst.search) table=new MyTable();
       else table=MyData.inst.get_table_vacfull();
       try{
            KXmlParser parser=new KXmlParser();
            parser.setInput(new InputStreamReader(new ByteArrayInputStream(s.getBytes("UTF-8")),"UTF-8"));
            parser.nextTag();
            parser.require(XmlPullParser.START_TAG, null, "vac_full");
            String name=parser.getAttributeValue("","text");
            String content="";
            while(parser.nextTag() == XmlPullParser.START_TAG) {
                parser.require(XmlPullParser.START_TAG, null, "data");
                content=content+lspars(parser.getAttributeValue("","text"))+"\n";
                parser.nextText();
                //parser.require(XmlPullParser.END_TAG, null, "data");
            }
            //parser.require(XmlPullParser.END_TAG, null, "vac_full");
            table.add("1",name,content);
            SContent.inst.load_data(table);
        }catch(Exception e){}
     }

    public void pars_seclist(String s){
        MyData.inst.table_sec=new MyTable();
        MyTable table=MyData.inst.table_sec;
        try{
            KXmlParser parser=new KXmlParser();
            parser.setInput(new InputStreamReader(new ByteArrayInputStream(s.getBytes("UTF-8")),"UTF-8"));
            parser.nextTag();
            parser.require(XmlPullParser.START_TAG, null, "sec_list");
            while(parser.nextTag() == XmlPullParser.START_TAG) {
                parser.require(XmlPullParser.START_TAG, null, "sec");
                table.add(lspars(parser.getAttributeValue("","id")),
                                                   lspars(parser.getAttributeValue("","text")), null);
                parser.nextText();
                //parser.require(XmlPullParser.END_TAG, null, "sec");
            }
            //parser.require(XmlPullParser.END_TAG, null, "sec_list");
            if (ScreenCanvas.inst.current_canvas.equals(SObiav.inst)) SObiav.inst.loadlist(table);
            else SObiav_add.inst.loadlist(table);
        }catch(Exception e){}
    }

    public void pars_subseclist(String s){
        MyData.inst.table_sec.set_col3(new MyTable(),MyData.inst.sec_selected_id);
        MyTable table=MyData.inst.table_sec.get_col3(MyData.inst.sec_selected_id);
        try{
            KXmlParser parser=new KXmlParser();
            parser.setInput(new InputStreamReader(new ByteArrayInputStream(s.getBytes("UTF-8")),"UTF-8"));
            parser.nextTag();
            parser.require(XmlPullParser.START_TAG, null, "subsec_list");
            while(parser.nextTag() == XmlPullParser.START_TAG) {
                parser.require(XmlPullParser.START_TAG, null, "subs");
                table.add(lspars(parser.getAttributeValue("","id")),
                                                   lspars(parser.getAttributeValue("","text")), null);
                parser.nextText();
                //parser.require(XmlPullParser.END_TAG, null, "subs");
            }
            //parser.require(XmlPullParser.END_TAG, null, "subsec_list");
            if (ScreenCanvas.inst.current_canvas.equals(SObiav.inst)) SObiav.inst.loadlist(table);
            else SObiav_add.inst.loadlist(table);
        }catch(Exception e){}
    }

    public void pars_ann(String s){
        MyTable table;
        if (SObiav_list.inst.search) table=MyData.inst.get_table_search();
        else {
            MyData.inst.ob_pages.add(Integer.toString(MyData.inst.ob_page),null,new MyTable());
            table=MyData.inst.ob_pages.get_col3(MyData.inst.ob_pages.col1.indexOf(
                                                                Integer.toString(MyData.inst.ob_page)));
        }
        try{
            KXmlParser parser=new KXmlParser();
            parser.setInput(new InputStreamReader(new ByteArrayInputStream(s.getBytes("UTF-8")),"UTF-8"));
            parser.nextTag();
            parser.require(XmlPullParser.START_TAG, null, "ann_list");
            table.table_prop1=Integer.parseInt(parser.getAttributeValue("","page_count"));
            while(parser.nextTag() == XmlPullParser.START_TAG) {
                parser.require(XmlPullParser.START_TAG, null, "ann");
                table.add(lspars(parser.getAttributeValue("","id")),
                                                   lspars(parser.getAttributeValue("","text")), null);
                parser.nextText();
                //parser.require(XmlPullParser.END_TAG, null, "ann");
            }
            //parser.require(XmlPullParser.END_TAG, null, "ann_list");
            SObiav_list.inst.load_data(table);
        }catch(Exception e){}
    }

    public void pars_annfull(String s){
        MyTable table;
        if (SObiav_list.inst.search) table=new MyTable();
        else{
            int obpage_id=MyData.inst.ob_pages.col1.indexOf(Integer.toString(MyData.inst.ob_page));
            int ann_full_id=MyData.inst.ob_pages.get_col3(obpage_id).col1.indexOf(Integer.toString(MyData.inst.ob_ann_full));
            MyData.inst.ob_pages.get_col3(obpage_id).set_col3(new MyTable(), ann_full_id);
            table=MyData.inst.ob_pages.get_col3(obpage_id).get_col3(ann_full_id);
        }
        try{
            KXmlParser parser=new KXmlParser();
            parser.setInput(new InputStreamReader(new ByteArrayInputStream(s.getBytes("UTF-8")),"UTF-8"));
            parser.nextTag();
            parser.require(XmlPullParser.START_TAG, null, "ann_full");
            String title=lspars(parser.getAttributeValue("","text"));
            String content="";
            while(parser.nextTag() == XmlPullParser.START_TAG) {
                parser.require(XmlPullParser.START_TAG, null, "data");
                content=content+lspars(parser.getAttributeValue("","text"))+"\n";
                parser.nextText();
                //parser.require(XmlPullParser.END_TAG, null, "data");
            }
            table.add("1", title, content);
            //parser.require(XmlPullParser.END_TAG, null, "ann_full");
            SContent.inst.load_data(table);
        }catch(Exception e){}
    }

    public void pars_hello(String s){
        KXmlParser parser=new KXmlParser();
        try{
            parser.setInput(new InputStreamReader(new ByteArrayInputStream(s.getBytes("UTF-8")),"UTF-8"));
            parser.nextTag();
            parser.require(XmlPullParser.START_TAG, null, "hello_ok");
            String scroll=lspars(parser.getAttributeValue("","scroll"));
            if (scroll!=null && !scroll.equals("")) CG.inst.beg_string=scroll;
            String adver=lspars(parser.getAttributeValue("","adver"));
            if (adver!=null && !adver.equals("")) SFirst.inst.load_data(adver);
            Config.server_prot=lspars(parser.getAttributeValue("","prot"));
            Config.server_client=lspars(parser.getAttributeValue("","client"));
            SConnect.inst.set_load(6);
            Config.inst.verifyVersion();
        }catch(Exception e){e.printStackTrace();}
    }

    public void pars_ann_add(String s){
        KXmlParser parser=new KXmlParser();
        try{
            parser.setInput(new InputStreamReader(new ByteArrayInputStream(s.getBytes("UTF-8")),"UTF-8"));
            parser.nextTag();
            parser.require(XmlPullParser.START_TAG, null, "ann_ok");
            String status=parser.getAttributeValue("","status");
            if (status.equals("ok")){
                String id=parser.getAttributeValue("","id");
                String pass=parser.getAttributeValue("","pass");
                SObiav_add_load.inst.load_data("���������� ��������� � �������. ID ���������: "+id+
                " ������ ��� ������� � �������������� ����������:\n"+pass+
                "\n����������� ��������� ���.");
                if (!id.equals("") && !pass.equals("")) Config.inst.pass_cache+=id+":"+pass+";";
            }else{
                String text=parser.getAttributeValue("","text");
                SObiav_add_load.inst.load_data("������! ���������� �� ��������� � �������. ������: "+text+".");
            }
            //parser.require(XmlPullParser.END_TAG, null, "ann_ok");
        }catch(Exception e){}
    }

    public void pars_alive(String s){
        KXmlParser parser=new KXmlParser();
        try{
            parser.setInput(new InputStreamReader(new ByteArrayInputStream(s.getBytes("UTF-8")),"UTF-8"));
            parser.nextTag();
            parser.require(XmlPullParser.START_TAG, null, "alive_ok");
            String scroll=parser.getAttributeValue("","scroll");
            if (scroll!=null && !scroll.equals("")) CG.inst.beg_string=scroll;
            String adver=parser.getAttributeValue("","adver");
            if (adver!=null && !adver.equals("")) SFirst.inst.load_data(adver);
        }catch(Exception e){}
    }
}
