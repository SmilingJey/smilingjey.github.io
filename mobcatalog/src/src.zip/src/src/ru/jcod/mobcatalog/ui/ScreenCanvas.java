package ru.jcod.mobcatalog.ui;

import javax.microedition.lcdui.Canvas;
import javax.microedition.lcdui.Graphics;

public class ScreenCanvas extends Canvas{

    public static ScreenCanvas inst;
    public ICanvas current_canvas;

    public ScreenCanvas(){
        super();
        inst=this;
        CG.inst.width=this.getWidth();
    }

    protected void paint(Graphics g){
        CG.inst.height=this.getHeight();
        g.setColor(CG.inst.background);
        g.fillRect(0,0,CG.inst.width,CG.inst.height);
        current_canvas.paint(g);
    }

    protected void keyRepeated(int keyCode){
        int NormalCode=getNormalCode(keyCode);
        String keyname=getKeyName(keyCode);
        int key=0;
        if (keyname.equals("2") || NormalCode==1){
            key=1;
        }else if (keyname.equals("4") || NormalCode==2){
            key=2;
        }else if (keyname.equals("6") || NormalCode==5){
            key=5;
        }else if (keyname.equals("8") || NormalCode==6){
            key=6;
        }
        if (key==1 || key==2 || key==5 || key==6)current_canvas.keyPressed(key);
        //repaint();
    }
    protected void keyPressed(int i){
       /*-6 - ����� �������
        -7 - ������ �������
        -8 - �����
        1 - �����
        6 - ����
        2 - �����
        5 - ������*/
        int keyCode=i;
        int NormalCode=getNormalCode(keyCode);
        String keyname=getKeyName(keyCode);
        int key=0;
        if (keyname.equals("1") || NormalCode==-6){
            key=-6;
        }else if (keyname.equals("3") || NormalCode==-7){
            key=-7;
        }else if (keyname.equals("2") || NormalCode==1){
            key=1;
        }else if (keyname.equals("4") || NormalCode==2){
            key=2;
        }else if (keyname.equals("6") || NormalCode==5){
            key=5;
        }else if (keyname.equals("5") || NormalCode==-8){
            key=-8;
        }else if (keyname.equals("8") || NormalCode==6){
            key=6;
        }
        current_canvas.keyPressed(key);
        repaint();
    }

    public int getNormalCode(int i) {
        int j = 0;
        String s1="", s2="";
        j = getGameAction(i);
        try {
            s1 = getKeyName(i);
        }catch(IllegalArgumentException _ex) {s1 = null;}
        if(s1 != null){//String s2;
            if((s2 = s1.toLowerCase()).equals("soft1") ||
                s2.equals("Softkey 1") || s2.equals("softkey 1 ") ||
                s2.equals("soft 1") || s2.equals("soft_1") ||
                s2.equals("softkey 1") || s2.startsWith("left soft"))
                return -6;
            if(s2.equals("soft2") || s2.equals("soft 2") ||
                s2.equals("Softkey 4") || s2.equals("softkey 4 ") ||
                s2.equals("soft_2") || s2.equals("softkey 4") ||
                s2.startsWith("right soft"))
                return -7;
            if(j == Canvas.FIRE && i!=Canvas.KEY_NUM5){
                return -8;
            }else if(j == Canvas.LEFT && i!=Canvas.KEY_NUM4){
                return 2;
            }else if(j == Canvas.RIGHT && i!=Canvas.KEY_NUM6){
                return 5;
            }else if(j == Canvas.UP && i!=Canvas.KEY_NUM2){
                return 1;
            }else if(j == Canvas.DOWN && i!=Canvas.KEY_NUM8){
                return 6;
            }
            if(s2.equals("clear") || s2.equals("back") || s2.equals("send"))
                return 7;
            if(s2.equals("select") || s2.equals("ok") || s2.equals("start") ||
                s2.equals("����������� �������") || s2.equals("������� ������") ||
                s2.equals("������� ������") || s2.equals("����������� ������� ������") ||
                s2.equals("����������� ������� ������ ") ||
                s2.equals("����������� ������� ������") ||
                s2.equals("����������� �������") ||
                s2.equals("����������� ������� ������") ||
                s2.equals("fire") || s2.equals("�����!") || s2.equals("�����!") ||
                s2.equals("navi-center"))
                return -8;
            if(s2.equals("up") || s2.equals("navi-up") || s2.equals("up arrow") ||
                s2.equals("�����") || s2.equals("�����") )
                return 1;
            if(s2.equals("down") || s2.equals("navi-down") || s2.equals("down arrow") ||
                s2.equals("����") || s2.equals("����") )
                return 6;
            if(s2.equals("left") || s2.equals("navi-left") || s2.equals("�����") ||
                s2.equals("left arrow") || s2.equals("sideup"))
                return 2;
            if(s2.equals("right") || s2.equals("navi-right") || s2.equals("������") ||
                s2.equals("right arrow") || s2.equals("sidedown"))
                return 5;
            if(s2.equals("q") || s2.equals("w"))
                return -6;
            if(s2.equals("o") || s2.equals("p"))
                return -7;
            if(s2.equals("escape"))
                return 7;
            }
            if(i == -6 || i == -21 || i == 21 || i == 105 || i == -202 || i == 112 || i == 57345)
                return -6;
            if(i == -7 || i == -22 || i == 22 || i == 106 || i == -203 || i == 113 || i == 57346)
                return -7;
            if(i == -5 || i == -10 || i == -20 || i == 20 || i == 23 || i == -14 ||
                i == -26 || i == -200 || i == 10 || i == 13)
                return 8;
            if(i == -8 || i == -11 || i == -16 || i == -19 || i == -204)
                return -7;
            switch(i){
                case 35: // �#�
                case 42: // �*�
                case 48: // �0?
                case 49: // �1?
                case 50: // �2?
                case 51: // �3?
                case 52: // �4?
                case 53: // �5?
                case 54: // �6?
                case 55: // �7?
                case 56: // �8?
                case 57: // �9?
                return i;
            }
            if(j != 0) return j;
            else return i;
    }

    public void set_current_canvas(ICanvas c){
        c.setActive();
        current_canvas=c;
    }
}
