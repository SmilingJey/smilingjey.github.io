package ru.jcod.mobcatalog.net;

import ru.jcod.mobcatalog.ui.MyAlert;
import ru.jcod.mobcatalog.ui.SImage;
import ru.jcod.mobcatalog.ui.SContent;
import ru.jcod.mobcatalog.*;
import ru.jcod.mobcatalog.net.Net_connect;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import javax.microedition.lcdui.Display;
import org.kxml2.io.KXmlParser;
import org.xmlpull.v1.XmlPullParser;

public class ReaderFile implements Runnable{

    public boolean stop=false;
	private Net_connectFile server;
	private InputStream in;
    public String stop_word="";
    private String otvet="";
    private int c;
    public boolean process_data=false;
    StringBuffer sb;
    boolean get_file=false;
    public int file_size=0;
    public int file_get=0;
    private byte[] file;

	public ReaderFile(Net_connectFile server){
		super();
		this.server=server;
		in=server.in;
	}

	public void run(){
		try {
			while(!stop){
	             otvet="";
                 sb=new StringBuffer();
	             while(true){
	                  c=in.read();
                      Net_connect.inst.set_loadb(1);
                      if (get_file){
                          file[file_get]=(byte)c;
                          file_get++;
                          if (file_get>=file_size) break;
                      }else{
                          otvet+=(char)c;
                          if (otvet.endsWith("</file_g>")) break;
                      }
	              }
                  if (get_file){
                      load_image();
                      stop=true;
                  }else{
                      pars_file_g(otvet);
                  }
			}
		}catch (IOException e) {
            MyAlert da=new MyAlert("��������� ����� ����������, ���� �� �������� "+e.getMessage());
            Display.getDisplay(MobileCatalog.inst).setCurrent(da);
        }
         server.disconnect();
	}

    public void pars_file_g(String s){
        KXmlParser parser=new KXmlParser();
        get_file=true;
        try{
            parser.setInput(new InputStreamReader(new ByteArrayInputStream(s.getBytes("UTF-8")),"UTF-8"));
            parser.nextTag();
            parser.require(XmlPullParser.START_TAG, null, "file_g");
            file_size=Integer.parseInt(parser.getAttributeValue("","pS"));
            file=new byte[file_size];
        }catch(Exception e){}
    }

    public void load_image(){
        get_file=false;
        if (server.type==0) SImage.inst.load_data(file);
        else SContent.inst.load_logo(file);
        file=null;
    }
}
