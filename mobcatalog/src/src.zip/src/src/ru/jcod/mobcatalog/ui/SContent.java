package ru.jcod.mobcatalog.ui;

import ru.jcod.mobcatalog.data.MyTable;
import ru.jcod.mobcatalog.*;
import ru.jcod.mobcatalog.net.Net_connectFile;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;

public class SContent implements ICanvas{

    public static SContent inst;
    private MultiLineText MLT;
    private boolean isFirstRun=true; 
    private String leftbutton[]={"�����"};
    private String rightbutton_obiav[]={"������","������.","��.����"};
    private String rightbutton_default[]={"��.����"};
    private String rightbutton_firm1[]={"������","�����","��.����","�����"};
    private String rightbutton_firm2[]={"������","��.����","�����"};
    private String rightbutton[]={"��.����"};
    private boolean show_leftbutton=false;
    private boolean show_rightbutton=false;
    private int active_button=0;
    public MyTable table=null;
    public boolean load_data=true;
    public int active_page=0;
    String title="";
    public int data_type=0;
    private Image img;
    private int h,w,hh,h_t;
    public boolean load_logo=true;

    public SContent(){
        inst = this;
    }

    public void paint(Graphics g) {
       if (load_data) load_logo=true;
       CG.p_beg_string(g);
       title="";
       if (load_data) title=" ";
       else if (table==null) title="���������";
       else if (table.size()<=0) title="���������";
       else title=table.get_col2(0);
       CG.p_title(g,title,false);
       if (load_data) CG.p_wait(g);
       else if (table==null) CG.p_nodata(g);
       else if (table.size()<=0 || table.empty()) CG.p_nodata(g);
       else p_text(g);
       if (!load_logo){
           g.drawImage(img,0,hh+2, Graphics.LEFT | Graphics.TOP);
       }
       if (data_type==2) {
           rightbutton=rightbutton_default;
           CG.p_button(g, leftbutton, rightbutton, show_leftbutton, show_rightbutton, active_button,"�����","��.����");
       }else if(data_type==0){
           if (table!=null && table.size()>1) rightbutton=rightbutton_firm1;
           else rightbutton=rightbutton_firm2;
           CG.p_button(g, leftbutton, rightbutton, show_leftbutton, show_rightbutton, active_button,"�����","�������");
       }else{
           rightbutton=rightbutton_default;
           CG.p_button(g, leftbutton, rightbutton, show_leftbutton, show_rightbutton, active_button,"�����","��.����");
       }
    }

    public void p_text(Graphics g){
        if (isFirstRun==true){
            MLT = new MultiLineText();
            MLT.SetTextPar(1, h_t, CG.inst.width-1,CG.inst.height-h_t-CG.inst.button_font.getHeight()-3,10,
                    CG.inst.text_FontSize,CG.inst.text_FontStyle,CG.inst.text_FontType,g,
                    table.get_col3_s(0),true);
            isFirstRun=false;
        }
       g.setColor(CG.inst.text_textcolor);
       MLT.DrawMultStr();
    }

    public void keyPressed(int key){
       if (key == 1)       {
            if (show_leftbutton || show_rightbutton){
                if (active_button!=(show_leftbutton?leftbutton.length-1:rightbutton.length-1)) active_button++;
                else active_button=0;
            }else{
                if (MLT!=null) MLT.MoveUp();
            }
       }else if (key == 6){
            if (show_leftbutton || show_rightbutton){
                if (active_button!=0) active_button--;
                else active_button=show_leftbutton?leftbutton.length-1:rightbutton.length-1;
            }else{
                if (MLT!=null) MLT.MoveDown();
            }
       }else if (key == -6){
           if (leftbutton.length>1){
               show_leftbutton=!show_leftbutton;
               active_button=0;
           }else{
              if (data_type==0){
                  ScreenCanvas.inst.set_current_canvas(SNames.inst);
              }else if(data_type==1){
                  ScreenCanvas.inst.set_current_canvas(SVac.inst);
              }else if(data_type==2){
                  ScreenCanvas.inst.set_current_canvas(SObiav_list.inst);
              }
           }
       }else if (key == -7){
           if (rightbutton.length>1){
               show_rightbutton=!show_rightbutton;
               active_button=0;
           }else{
              if(data_type==1){
                  ScreenCanvas.inst.set_current_canvas(SMain.inst);
              }else if(data_type==2){
                  ScreenCanvas.inst.set_current_canvas(SMain.inst);
              }
           }
       }else if (key == 2){
           MLT.PageUp();
           /*if (!load_data && table!=null && !table.empty()){
               if (active_page!=0) active_page--;
               else active_page=table.size()-1;
           }*/
       }else if (key == 5){
           MLT.PageDown();
           /*if (!load_data && table!=null && !table.empty()){
                if (active_page!=table.size()-1) active_page++;
                else active_page=0;
           }*/
       }else if (key == -8){
           if(show_leftbutton){
               show_leftbutton=false;
               active_button=0;
           }else if(show_rightbutton){
               if (data_type==0){
                  if (table!=null && table.size()>1){
                      if (active_button==1){
                          if (!load_data && table!=null && table.size()>1){
                                SImage.inst.load_data=true;
                                ScreenCanvas.inst.set_current_canvas(SImage.inst);
                                new Thread(new Net_connectFile("<file id="+table.get_col1(1)+"></file>",0)).start();
                          }
                      }else if (active_button==2){
                          ScreenCanvas.inst.set_current_canvas(SMain.inst);
                      }else if (active_button==3){
                          MobileCatalog.quitApp();
                      }
                  }else{
                      if (active_button==1){
                          ScreenCanvas.inst.set_current_canvas(SMain.inst);
                      }else if (active_button==2){
                          MobileCatalog.quitApp();
                      }
                  }
               }else if(data_type==1){

               }else if(data_type==2){
                  if (active_button==1){

                  }else if (active_button==2){
                      ScreenCanvas.inst.set_current_canvas(SMain.inst);
                  }
               }
               show_rightbutton=false;
               active_button=0;
           } else{

           }
       }
    }

    public void load_data(MyTable table){
        this.table=table;
        load_data=false;
        h_t=hh;
        isFirstRun=true;
        if (Config.inst.get_loadlogo() && data_type==0 && table!=null && table.get_col1(0)!=0){
            new Thread(new Net_connectFile("<file id="+table.get_col1(0)+"></file>",1)).start();
        }
        ScreenCanvas.inst.repaint();
    }

    public void setActive(){
       hh=CG.inst.beg_string_font.getHeight()+ CG.inst.title_string_font.getHeight()+6;
    }

    public void load_logo(byte[] b){
        img=Image.createImage(b, 0, b.length);
        h=img.getHeight();
        w=img.getWidth();
        load_logo=false;
        h_t=hh+h+4;
        isFirstRun=true;
        ScreenCanvas.inst.repaint();
    }
}
