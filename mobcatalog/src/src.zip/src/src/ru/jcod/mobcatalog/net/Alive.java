package ru.jcod.mobcatalog.net;

import ru.jcod.mobcatalog.data.MyLocate;

public class Alive implements Runnable{

    private int time=200000;
    private boolean stop=false;

    public void run() {
        while(!stop){
            try {
                Thread.sleep(time);
            } catch (InterruptedException ex) {
                System.err.println("own:: Interrupted: "+ex.getMessage());
            }
            if (Net_connect.inst!=null && !MyLocate.inst.get_city().equals("-1")){
                Net_connect.inst.send("<alive id_city="+MyLocate.inst.get_city()+"></alive>");
            }
        }
    }

    public void stop(){
        stop=true;

    }

}
