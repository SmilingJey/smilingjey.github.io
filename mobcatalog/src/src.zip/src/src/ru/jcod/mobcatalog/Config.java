package ru.jcod.mobcatalog;

import ru.jcod.mobcatalog.data.MyLocate;
import ru.jcod.mobcatalog.ui.MyAlert;
import ru.jcod.mobcatalog.ui.CG;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.Random;
import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;
import javax.microedition.rms.RecordStore;
import javax.microedition.rms.RecordStoreException;
import ru.jcod.mobcatalog.net.Net_connect;

public class Config implements CommandListener {

    public static Config inst;
    public MIDlet midlet;

    public static final String prot="1";
    public static final String client="1.0 beta";

    public static String server_prot="";
    public static String server_client="";

    public int trafik=0;
    public String pass_cache="_";

    public void verifyVersion(){
        /*if (!client.equals(server_client)){
           MyAlert da=new MyAlert("�������� ����� ����� ������ ���������: "+server_client+
                                    ". �� ������ ������� � � ������ ����� mobcatalog.ru");
           Display.getDisplay(MobileCatalog.inst).setCurrent(da);
        }*/
        if (!prot.equals(server_prot)){
           MyAlert da=new MyAlert("������ ���������� ������ ������ ���������. �������� ������ ��� ������."+
                   "�������� ��������� ������ ��������� � ����� mobcatalog.ru");
           Display.getDisplay(MobileCatalog.inst).setCurrent(da);
        }
    }


    //<editor-fold defaultstate="collapsed" desc=" Generated Fields ">//GEN-BEGIN:|fields|0|
    private Form form;
    private ChoiceGroup choiceGroup;
    private ChoiceGroup choiceGroup1;
    private TextField textField;
    private ChoiceGroup choiceGroup2;
    private ChoiceGroup choiceGroup3;
    private Command okCommand;
    private Command cancelCommand;
    //</editor-fold>//GEN-END:|fields|0|

    /**
     * The Config constructor.
     * @param midlet the midlet used for getting
     */
    public Config (MIDlet midlet) {
        inst=this;
        this.midlet=midlet;
    }

    //<editor-fold defaultstate="collapsed" desc=" Generated Methods ">//GEN-BEGIN:|methods|0|
    //</editor-fold>//GEN-END:|methods|0|

    //<editor-fold defaultstate="collapsed" desc=" Generated Method: initialize ">//GEN-BEGIN:|0-initialize|0|0-preInitialize
    /**
     * Initilizes the application.
     * It is called only once when the MIDlet is started. The method is called before the <code>startMIDlet</code> method.
     */
    private void initialize() {//GEN-END:|0-initialize|0|0-preInitialize
        // write pre-initialize user code here
//GEN-LINE:|0-initialize|1|0-postInitialize
        // write post-initialize user code here
    }//GEN-BEGIN:|0-initialize|2|
    //</editor-fold>//GEN-END:|0-initialize|2|

    //<editor-fold defaultstate="collapsed" desc=" Generated Method: switchDisplayable ">//GEN-BEGIN:|2-switchDisplayable|0|2-preSwitch
    /**
     * Switches a current displayable in a display. The <code>display</code> instance is taken from <code>getDisplay</code> method. This method is used by all actions in the design for switching displayable.
     * @param alert the Alert which is temporarily set to the display; if <code>null</code>, then <code>nextDisplayable</code> is set immediately
     * @param nextDisplayable the Displayable to be set
     */
    public void switchDisplayable(Alert alert, Displayable nextDisplayable) {//GEN-END:|2-switchDisplayable|0|2-preSwitch
        // write pre-switch user code here
        Display display = getDisplay();//GEN-BEGIN:|2-switchDisplayable|1|2-postSwitch
        if (alert == null) {
            display.setCurrent(nextDisplayable);
        } else {
            display.setCurrent(alert, nextDisplayable);
        }//GEN-END:|2-switchDisplayable|1|2-postSwitch
        // write post-switch user code here
    }//GEN-BEGIN:|2-switchDisplayable|2|
    //</editor-fold>//GEN-END:|2-switchDisplayable|2|

    //<editor-fold defaultstate="collapsed" desc=" Generated Method: commandAction for Displayables ">//GEN-BEGIN:|4-commandAction|0|4-preCommandAction
    /**
     * Called by a system to indicated that a command has been invoked on a particular displayable.
     * @param command the Command that was invoked
     * @param displayable the Displayable where the command was invoked
     */
    public void commandAction(Command command, Displayable displayable) {//GEN-END:|4-commandAction|0|4-preCommandAction
        // write pre-action user code here
        if (displayable == form) {//GEN-BEGIN:|4-commandAction|1|15-preAction
            if (command == cancelCommand) {//GEN-END:|4-commandAction|1|15-preAction
                loadconf();
//GEN-LINE:|4-commandAction|2|15-postAction
                MobileCatalog.inst.set_screancanvas();


            } else if (command == okCommand) {//GEN-LINE:|4-commandAction|3|13-preAction
                saveconf();
//GEN-LINE:|4-commandAction|4|13-postAction
                MobileCatalog.inst.set_screancanvas();
            }//GEN-BEGIN:|4-commandAction|5|4-postCommandAction
        }//GEN-END:|4-commandAction|5|4-postCommandAction
        // write post-action user code here
    }//GEN-BEGIN:|4-commandAction|6|
    //</editor-fold>//GEN-END:|4-commandAction|6|

    //<editor-fold defaultstate="collapsed" desc=" Generated Getter: form ">//GEN-BEGIN:|11-getter|0|11-preInit
    /**
     * Returns an initiliazed instance of form component.
     * @return the initialized component instance
     */
    public Form getForm() {
        if (form == null) {//GEN-END:|11-getter|0|11-preInit
            // write pre-init user code here
            form = new Form("\u041D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0438", new Item[] { getChoiceGroup(), getChoiceGroup1(), getChoiceGroup2(), getTextField(), getChoiceGroup3() });//GEN-BEGIN:|11-getter|1|11-postInit
            form.addCommand(getOkCommand());
            form.addCommand(getCancelCommand());
            form.setCommandListener(this);//GEN-END:|11-getter|1|11-postInit
            // write post-init user code here
        }//GEN-BEGIN:|11-getter|2|
        return form;
    }
    //</editor-fold>//GEN-END:|11-getter|2|

    //<editor-fold defaultstate="collapsed" desc=" Generated Getter: choiceGroup ">//GEN-BEGIN:|16-getter|0|16-preInit
    /**
     * Returns an initiliazed instance of choiceGroup component.
     * @return the initialized component instance
     */
    public ChoiceGroup getChoiceGroup() {
        if (choiceGroup == null) {//GEN-END:|16-getter|0|16-preInit
            // write pre-init user code here
            choiceGroup = new ChoiceGroup("\u0426\u0432\u0435\u0442\u043E\u0432\u0430\u044F \u0441\u0445\u0435\u043C\u0430", Choice.EXCLUSIVE);//GEN-BEGIN:|16-getter|1|16-postInit
            choiceGroup.append("\u0433\u043E\u043B\u0443\u0431\u0430\u044F", null);
            choiceGroup.append("\u0441\u0435\u0440\u0430\u044F", null);
            choiceGroup.append("\u0447\u0435\u0440\u043D\u0430\u044F", null);
            choiceGroup.append("\u0437\u0435\u043B\u0435\u043D\u0430\u044F", null);
            choiceGroup.append("\u043A\u0440\u0430\u0441\u043D\u0430\u044F", null);
            choiceGroup.setSelectedFlags(new boolean[] { false, false, false, false, false });
	//GEN-END:|16-getter|1|16-postInit
            // write post-init user code here
        }//GEN-BEGIN:|16-getter|2|
        return choiceGroup;
    }
    //</editor-fold>//GEN-END:|16-getter|2|

    //<editor-fold defaultstate="collapsed" desc=" Generated Getter: choiceGroup1 ">//GEN-BEGIN:|22-getter|0|22-preInit
    /**
     * Returns an initiliazed instance of choiceGroup1 component.
     * @return the initialized component instance
     */
    public ChoiceGroup getChoiceGroup1() {
        if (choiceGroup1 == null) {//GEN-END:|22-getter|0|22-preInit
            // write pre-init user code here
            choiceGroup1 = new ChoiceGroup("\u0420\u0430\u0437\u043C\u0435\u0440 \u0448\u0440\u0438\u0444\u0442\u0430", Choice.EXCLUSIVE);//GEN-BEGIN:|22-getter|1|22-postInit
            choiceGroup1.append("\u043C\u0435\u043B\u043A\u0438\u0439", null);
            choiceGroup1.append("\u0441\u0440\u0435\u0434\u043D\u0438\u0439", null);
            choiceGroup1.append("\u043A\u0440\u0443\u043F\u043D\u044B\u0439", null);
            choiceGroup1.setSelectedFlags(new boolean[] { false, false, false });
	//GEN-END:|22-getter|1|22-postInit
            // write post-init user code here
        }//GEN-BEGIN:|22-getter|2|
        return choiceGroup1;
    }
    //</editor-fold>//GEN-END:|22-getter|2|

    //<editor-fold defaultstate="collapsed" desc=" Generated Getter: okCommand ">//GEN-BEGIN:|12-getter|0|12-preInit
    /**
     * Returns an initiliazed instance of okCommand component.
     * @return the initialized component instance
     */
    public Command getOkCommand() {
        if (okCommand == null) {//GEN-END:|12-getter|0|12-preInit
            // write pre-init user code here
            okCommand = new Command("\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C", Command.OK, 0);//GEN-LINE:|12-getter|1|12-postInit
            // write post-init user code here
        }//GEN-BEGIN:|12-getter|2|
        return okCommand;
    }
    //</editor-fold>//GEN-END:|12-getter|2|

    //<editor-fold defaultstate="collapsed" desc=" Generated Getter: cancelCommand ">//GEN-BEGIN:|14-getter|0|14-preInit
    /**
     * Returns an initiliazed instance of cancelCommand component.
     * @return the initialized component instance
     */
    public Command getCancelCommand() {
        if (cancelCommand == null) {//GEN-END:|14-getter|0|14-preInit
            // write pre-init user code here
            cancelCommand = new Command("\u041E\u0442\u043C\u0435\u043D\u0430", Command.CANCEL, 0);//GEN-LINE:|14-getter|1|14-postInit
            // write post-init user code here
        }//GEN-BEGIN:|14-getter|2|
        return cancelCommand;
    }
    //</editor-fold>//GEN-END:|14-getter|2|

    //<editor-fold defaultstate="collapsed" desc=" Generated Getter: textField ">//GEN-BEGIN:|27-getter|0|27-preInit
    /**
     * Returns an initiliazed instance of textField component.
     * @return the initialized component instance
     */
    public TextField getTextField() {
        if (textField == null) {//GEN-END:|27-getter|0|27-preInit
            // write pre-init user code here
            textField = new TextField("\u042D\u043B\u0435\u043C\u0435\u043D\u0442\u043E\u0432 \u043D\u0430 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0435", "20", 32, TextField.NUMERIC);//GEN-BEGIN:|27-getter|1|27-postInit
            //textField.setInitialInputMode("UCB_BASIC_LATIN");//GEN-END:|27-getter|1|27-postInit
            // write post-init user code here
        }//GEN-BEGIN:|27-getter|2|
        return textField;
    }
    //</editor-fold>//GEN-END:|27-getter|2|

    //<editor-fold defaultstate="collapsed" desc=" Generated Getter: choiceGroup2 ">//GEN-BEGIN:|28-getter|0|28-preInit
    /**
     * Returns an initiliazed instance of choiceGroup2 component.
     * @return the initialized component instance
     */
    public ChoiceGroup getChoiceGroup2() {
        if (choiceGroup2 == null) {//GEN-END:|28-getter|0|28-preInit
            // write pre-init user code here
            choiceGroup2 = new ChoiceGroup("\u0428\u0440\u0438\u0444\u0442 \u0438\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u0438", Choice.EXCLUSIVE);//GEN-BEGIN:|28-getter|1|28-postInit
            choiceGroup2.append("\u043C\u0435\u043B\u043A\u0438\u0439", null);
            choiceGroup2.append("\u0441\u0440\u0435\u0434\u043D\u0438\u0439", null);
            choiceGroup2.append("\u043A\u0440\u0443\u043F\u043D\u044B\u0439", null);
            choiceGroup2.setSelectedFlags(new boolean[] { false, false, false });
		//GEN-END:|28-getter|1|28-postInit
            // write post-init user code here
        }//GEN-BEGIN:|28-getter|2|
        return choiceGroup2;
    }
    //</editor-fold>//GEN-END:|28-getter|2|

    //<editor-fold defaultstate="collapsed" desc=" Generated Getter: choiceGroup3 ">//GEN-BEGIN:|32-getter|0|32-preInit
    /**
     * Returns an initiliazed instance of choiceGroup3 component.
     * @return the initialized component instance
     */
    public ChoiceGroup getChoiceGroup3() {
        if (choiceGroup3 == null) {//GEN-END:|32-getter|0|32-preInit
            // write pre-init user code here
            choiceGroup3 = new ChoiceGroup("\u0417\u0430\u0433\u0440\u0443\u0436\u0430\u0442\u044C \u043B\u043E\u0433\u043E\u0442\u0438\u043F\u044B \u0444\u0438\u0440\u043C?", Choice.MULTIPLE);//GEN-BEGIN:|32-getter|1|32-postInit
            choiceGroup3.append("\u0417\u0430\u0433\u0440\u0443\u0436\u0430\u0442\u044C \u043B\u043E\u0433\u043E\u0442\u0438\u043F\u044B", null);
            choiceGroup3.setSelectedFlags(new boolean[] { false });
//GEN-END:|32-getter|1|32-postInit
            // write post-init user code here
        }//GEN-BEGIN:|32-getter|2|
        return choiceGroup3;
    }
    //</editor-fold>//GEN-END:|32-getter|2|

    /**
     * Returns a display instance.
     * @return the display instance.
     */
    public Display getDisplay () {
        return Display.getDisplay(midlet);
    }

    public String shema="�������";
    public String font="������";
    public String font_text="������";
    public boolean loadlogo=false;
    private String client_id;



    public static int randomInt(int minValue, int maxValue) {
        int rndValue;
        try {
            rndValue = new Random().nextInt()&(maxValue+minValue)-minValue; //maxValue-minValue -1)+minValue;
        } catch(Throwable t) {
            //System.out.println("Exception was thrown during call Random().nextInt() method: "+t);
            //System.out.println("value -1 will be return as Random integer variable.");
            rndValue = -1;
        }
        return rndValue;
    }

    public void loadconf(){
            String page_size="20";
            try {

            RecordStore recordstore = RecordStore.openRecordStore("mobilecat", true);
            if (recordstore.getNumRecords()==16){
            	shema=get_string(1,recordstore,true);
            	font=get_string(2,recordstore,true);
                MyLocate.inst.rg_id=get_string(3,recordstore,false);
                MyLocate.inst.rg_name=get_string(4,recordstore,true);
                MyLocate.inst.ray_id=get_string(5,recordstore,false);
                MyLocate.inst.ray_name=get_string(6,recordstore,true);
                MyLocate.inst.punkt_id=get_string(7,recordstore,false);
                MyLocate.inst.punkt_name=get_string(8,recordstore,true);
                MyLocate.inst.street_id=get_string(9,recordstore,false);
                MyLocate.inst.street_name=get_string(10,recordstore,true);
                page_size=get_string(11,recordstore,false);
                client_id=get_string(12,recordstore,false);
                font_text=get_string(13,recordstore,true);
                loadlogo=get_string(14,recordstore,false).equals("1");
                String s15=get_string(15,recordstore,false);
                if (s15== null || s15.equals("")) trafik=0;
                else trafik=Integer.parseInt(s15);
                pass_cache=get_string(16,recordstore,false);
            } else{
                recordstore.closeRecordStore();
                RecordStore.deleteRecordStore("mobilecat");
                recordstore = RecordStore.openRecordStore("mobilecat", true);
                //for(int i=1;i<recordstore.getNumRecords();i++) recordstore.deleteRecord(i);
                add_string(shema,  recordstore, true);
                add_string(font, recordstore, true);
                add_string(MyLocate.inst.rg_id,  recordstore, false);
                add_string(MyLocate.inst.rg_name,recordstore, true);
                add_string(MyLocate.inst.ray_id,recordstore, false);
                add_string(MyLocate.inst.ray_name, recordstore, true);
                add_string(MyLocate.inst.punkt_id,  recordstore, false);
                add_string(MyLocate.inst.punkt_name, recordstore, true);
                add_string(MyLocate.inst.street_id,recordstore, false);
                add_string(MyLocate.inst.street_name, recordstore, true);
                add_string(page_size, recordstore, false);
                client_id=getIMEI();
                if (client_id==null || client_id.length()<9) client_id=Integer.toString(randomInt(1,999999999));         
                add_string(client_id, recordstore, false);
                add_string(font_text, recordstore, true);
                add_string("0", recordstore, false);
                add_string("0", recordstore, false);
                add_string(pass_cache, recordstore, false);
            }
            recordstore.closeRecordStore();
        } catch (RecordStoreException rse) {
                MyAlert da=new MyAlert("RSE ERROR load: "+rse.getMessage());
                Display.getDisplay(MobileCatalog.inst).setCurrent(da);
        }

        for(int i=0;i<getChoiceGroup().size();i++){
            if(shema.equals(getChoiceGroup().getString(i))){
                getChoiceGroup().setSelectedIndex(i, true);
                break;
            }
        }

        for(int i=0;i<getChoiceGroup1().size();i++){
            if(font.equals(getChoiceGroup1().getString(i))){
                getChoiceGroup1().setSelectedIndex(i, true);
                break;
            }
        }

        for(int i=0;i<getChoiceGroup2().size();i++){
            if(font_text.equals(getChoiceGroup2().getString(i))){
                getChoiceGroup2().setSelectedIndex(i, true);
                break;
            }
        }
        getChoiceGroup3().setSelectedIndex(0, loadlogo);

        getTextField().setString(page_size);
        CG.inst.set_shemafont();
    }

    public String get_string(int id,RecordStore recordstore,boolean utf){
        try{
            if (recordstore.getRecordSize(id)==0) return "";
            else {       
                String s;
                if (utf) s=(new DataInputStream(new ByteArrayInputStream(recordstore.getRecord(id)))).readUTF();
                else s=new String(recordstore.getRecord(id));
                return s;
            }
        } catch (RecordStoreException rse) {
                MyAlert da=new MyAlert("RSE ERROR get "+id+" "+rse.getMessage());
                Display.getDisplay(MobileCatalog.inst).setCurrent(da);
        }catch(IOException e){

        }
        return "";
    }

    public void add_string(String s,RecordStore recordstore,boolean utf){
        try{
            if (utf){
                ByteArrayOutputStream bosPass = new ByteArrayOutputStream();
                DataOutputStream dosPass = new DataOutputStream(bosPass);
                dosPass.writeUTF(s);
                recordstore.addRecord(bosPass.toByteArray(), 0, bosPass.size());
            }else recordstore.addRecord(s.getBytes(),0, s.getBytes().length);
        }catch(IOException e){
        }catch(RecordStoreException rse){
            MyAlert da=new MyAlert("RSE add string "+s+" ERROR: "+rse.getMessage());
            Display.getDisplay(MobileCatalog.inst).setCurrent(da);
        }
    }

    public void set_string(String s,int id,RecordStore recordstore,boolean utf){
        try{
            if (utf){
                ByteArrayOutputStream bosPass = new ByteArrayOutputStream();
                DataOutputStream dosPass = new DataOutputStream(bosPass);
                dosPass.writeUTF(s);
                recordstore.setRecord(id, bosPass.toByteArray(), 0, bosPass.size());
            }else recordstore.setRecord(id,s.getBytes(),0, s.getBytes().length);
        }catch(IOException e){
        }catch(RecordStoreException rse){
            MyAlert da=new MyAlert("RSE ERROR set string |"+s+"| "+rse.getMessage());
            Display.getDisplay(MobileCatalog.inst).setCurrent(da);
        }
    }

    public void saveconf(){
        trafik+=Net_connect.inst.get_byteload();
        shema=getChoiceGroup().getString(getChoiceGroup().getSelectedIndex());
        font=getChoiceGroup1().getString(getChoiceGroup1().getSelectedIndex());
        font_text=getChoiceGroup2().getString(getChoiceGroup2().getSelectedIndex());
        String ll=getChoiceGroup3().isSelected(0)?"1":"0";
        String page_size;
        if (textField.getString()==null || textField.getString().equals("")) page_size="20";
        else page_size=textField.getString();
        try {
            RecordStore recordstore = RecordStore.openRecordStore("mobilecat", false);
            set_string(shema, 1, recordstore, true);
            set_string(font, 2, recordstore, true);
            set_string(MyLocate.inst.rg_id, 3, recordstore, false);
            set_string(MyLocate.inst.rg_name, 4, recordstore, true);
            set_string(MyLocate.inst.ray_id,5, recordstore, false);
            set_string(MyLocate.inst.ray_name, 6, recordstore, true);
            set_string(MyLocate.inst.punkt_id, 7, recordstore, false);
            set_string(MyLocate.inst.punkt_name, 8, recordstore, true);
            set_string(MyLocate.inst.street_id, 9, recordstore, false);
            set_string(MyLocate.inst.street_name, 10, recordstore, true);
            set_string(page_size, 11, recordstore, false);
            set_string(client_id, 12, recordstore, false);
            set_string(font_text, 13, recordstore, true);
            set_string(ll, 14, recordstore, false);
            set_string(trafik+"", 15, recordstore, false);
            set_string(pass_cache, 16, recordstore, false);
            recordstore.closeRecordStore();
        } catch (RecordStoreException rse){
              MyAlert da=new MyAlert("RSE ERROR: "+rse.getMessage());
             Display.getDisplay(MobileCatalog.inst).setCurrent(da);
        }
        CG.inst.set_shemafont();
    }

    public void loadloc(){
        
    }

    public void saveloc(){

    }

    public int get_page_size(){
        return Integer.parseInt(textField.getString().equals("")?"20":textField.getString());
    }

    public boolean get_loadlogo(){
        return getChoiceGroup3().isSelected(0);
    }

    public String get_clientid(){
        return client_id;
    }

    public static String getIMEI(){
    String out = "";
    try{
        out = System.getProperty("com.imei");
        if(out!= null && !out.equals("null") && !out.equals("")) return out;
        out = System.getProperty("phone.imei");
        if(out!= null && !out.equals("null") && !out.equals("")) return out;
        out = System.getProperty("com.nokia.IMEI");
        if(out!= null && !out.equals("null") && !out.equals("")) return out;
        out = System.getProperty("com.nokia.mid.imei");
        if(out!= null && !out.equals("null") && !out.equals("")) return out;
        out = System.getProperty("com.nokia.mid.imei");
        if(out!= null && !out.equals("null") && !out.equals("")) return out;
        out = System.getProperty("com.sonyericsson.imei");
        if(out!= null && !out.equals("null") && !out.equals("")) return out;
        out = System.getProperty("IMEI");
        if(out!= null && !out.equals("null") && !out.equals("")) return out;
        out = System.getProperty("com.motorola.IMEI");
        if(out!= null && !out.equals("null") && !out.equals("")) return out;
        out = System.getProperty("com.samsung.imei");
        if(out!= null && !out.equals("null") && !out.equals("")) return out;
        out = System.getProperty("com.siemens.imei");
        if(out!= null && !out.equals("null") && !out.equals("")) return out;
        out = System.getProperty("imei");
        if(out!= null && !out.equals("null") && !out.equals("")) return out;
		}catch(Exception e){
			return out==null?"":out;
		}
 		return out==null?"":out;
	}

    public String get_loadkb(){
        return Integer.toString(trafik/1024);
    }
}
