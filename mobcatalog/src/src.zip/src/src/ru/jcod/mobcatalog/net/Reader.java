package ru.jcod.mobcatalog.net;

import java.io.IOException;
import java.io.InputStream;
import javax.microedition.lcdui.Canvas;
import ru.jcod.mobcatalog.ui.CG;
import ru.jcod.mobcatalog.ui.ScreenCanvas;

public class Reader implements Runnable {

    public boolean stop = false;
    private InputStream in;
    private int[] intPhoneCharDiv = {(int) '�' - 192, (int) '�' - 168, (int) '�' - 184};
    private String otvet = "";
    private byte buff[];
    private int c, len;
    private boolean process_data = false;
    private StringBuffer sb;

    public Reader(InputStream in) {
        this.in = in;
    }

    public void run() {
        try {
            buff = new byte[16 * 1024];
            while (!stop) {
                sb = new StringBuffer();
                otvet = "";
                len = 0;
                while ((c = in.read()) != 1) {
                    buff[len] = (byte) c;
                    len++;
                }
                Net_connect.inst.set_loadb(len);
                for (int i = 0; i < len; i++) {
                    c = buff[i];
                    if (c < 0) {
                        c += 256;
                    }
                    if (c > 191 && c < 256) {
                        c += intPhoneCharDiv[0];
                    } else if (c == 168) {
                        c += intPhoneCharDiv[1];
                    } else if (c == 184) {
                        c += intPhoneCharDiv[2];
                    }
                    sb.append((char) c);
                }
                Parser.inst.pars(sb.toString());
            }
            in.close();
        } catch (IOException e) {
            Net_connect.inst.disconnect();
            //MyAlert da=new MyAlert("��������� ����� ����������, ������� ������ �����������: "+e.getMessage());
            //Display.getDisplay(MobileCatalog.inst).setCurrent(da);
            //CG.setFullScreenMode((Canvas) ScreenCanvas.inst, false);
            Net_connect.inst.connect();
        }
    }
}
