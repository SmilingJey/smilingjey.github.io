package ru.jcod.mobcatalog.data;


import ru.jcod.mobcatalog.ui.SLocate;
import ru.jcod.mobcatalog.net.Net_connect;
import java.util.Vector;

public class MyLocate {

    public static MyLocate inst;

    public MyLocate(){
        inst=this;
    }

    /*---------------- ������--------------------------*/
    public String rg_id="-1";
    public String rg_name="";
    private Vector v_rg_id;
    private Vector v_rg_name;

    public String get_selected_rg_id(){
        return rg_id;
    }

    public String get_selected_rg_name(){
        return rg_name;
    }

    public void set_selected_rg_id(String id){
        rg_id=id;
    }

    public void set_selected_rg_name(String name){
        rg_name=name;
    }

    public Vector get_v_rg_id(){
        return v_rg_id;
    }

    public Vector get_v_rg_name(){
        return v_rg_name;
    }

    public void load_rg(){
        if (v_rg_id==null || v_rg_name==null){
            v_rg_id=new Vector(1);
            v_rg_name=new Vector(1);
            Net_connect.inst.send("<rg></rg>");
        }else{
            SLocate.inst.loadlist(v_rg_name);
        }
    }

    public void addrg(String id, String name){
        v_rg_id.addElement(id);
        v_rg_name.addElement(name);
    }
    /*-------------------------------------------------------------*/

    /*------------------ �����, �����----------------------------------*/
    public String ray_id="-1";
    public String ray_name="";
    private Vector v_ray_id;
    private Vector v_ray_name;

    public String get_selected_ray_id(){
        return ray_id;
    }

    public String get_selected_ray_name(){
        return ray_name;
    }

    public void set_selected_ray_id(String id){
        ray_id=id;
    }

    public void set_selected_ray_name(String name){
        ray_name=name;
    }

    public Vector get_v_ray_id(){
        return v_ray_id;
    }

    public Vector get_v_ray_name(){
        return v_ray_name;
    }

    public void load_ray(){
        v_ray_id=null;
        v_ray_name=null;
        v_ray_id=new Vector(1);
        v_ray_name=new Vector(1);
        Net_connect.inst.send("<ray reg_id="+rg_id+"></ray>");
        /*addray(1,"dfg ���������� �������");
        addray(2,"dfgd ������������� �������");
        addray(3,"dgdfg ������������ �������");
        SLocate.instance.listload(v_ray_name);*/
    }

    public void addray(String id, String name){
        v_ray_id.addElement(id);
        v_ray_name.addElement(name);
    }
    /*----------------------------------------------------------------*/

    /*--------------------------��������� ����� ----------------------*/
    public String punkt_id="-1";
    public String punkt_name="";
    private Vector v_punkt_id;
    private Vector v_punkt_name;

    public String get_selected_punkt_id(){
        return punkt_id;
    }

    public String get_selected_punkt_name(){
        return punkt_name;
    }

    public void set_selected_punkt_id(String id){
        punkt_id=id;
    }

    public void set_selected_punkt_name(String name){
        punkt_name=name;
    }

    public Vector get_v_punkt_id(){
        return v_punkt_id;
    }

    public Vector get_v_punkt_name(){
        return v_punkt_name;
    }

    public void load_punkt(){
        v_punkt_id=null;
        v_punkt_name=null;
        v_punkt_id=new Vector(1);
        v_punkt_name=new Vector(1);
        Net_connect.inst.send("<punkt ray_id="+ray_id+"></punkt>");
    }

    public void addpunkt(String id, String name){
        v_punkt_id.addElement(id);
        v_punkt_name.addElement(name);
    }
    /*----------------------------------------------------------------*/

    /*-------------------------�����----------------------------------*/
    public String street_id="-1";
    public String street_name="";
    private Vector v_street_id;
    private Vector v_street_name;

    public String get_selected_street_id(){
        return street_id;
    }

    public String get_selected_street_name(){
        return street_name;
    }

    public void set_selected_street_id(String id){
        street_id=id;
    }

    public void set_selected_street_name(String name){
        street_name=name;
    }

    public Vector get_v_street_name(){
        return v_street_name;
    }

    public Vector get_v_street_id(){
        return v_street_id;
    }

    public void load_street(){
        v_street_id=null;
        v_street_name=null;
        v_street_id=new Vector(1);
        v_street_name=new Vector(1);
        Net_connect.inst.send("<street city_id="+get_city()+"></street>");
    }

    public void addstreet(String id, String name){
        v_street_id.addElement(id);
        v_street_name.addElement(name);
    }
    /*----------------------------------------------------------------*/

    public String get_city(){
        if (punkt_id.equals("-1")){
            if (!ray_id.equals("-1")) return ray_id;
            else return "-1";
        }else return punkt_id;
    }

    public String get_city_name(){
        if (punkt_id.equals("-1")){
            if (!ray_id.equals("-1")) return ray_name;
            else return "�� ������!";
        }else return punkt_name;
    }
}
