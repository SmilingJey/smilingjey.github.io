package ru.jcod.mobcatalog.ui;

import ru.jcod.mobcatalog.data.MyLocate;
import javax.microedition.lcdui.Graphics;

public class SFirst implements ICanvas{

    public static SFirst inst;
    private String title="�������",text=CG.First_text;
    private boolean isFirstRun=true;
    private MultiLineText MLT;
    private int hh;

    public SFirst(){
        inst = this;
    }

    public void paint(Graphics g) {
       CG.p_beg_string(g);
       CG.p_title(g,title,false);
       p_text(g);
       CG.p_button(g, null,null , false, false, 0, "� ���","�����");
    }

    public void p_text(Graphics g){
        if (isFirstRun==true){
            MLT = new MultiLineText();
            MLT.SetTextPar(1, hh, CG.inst.width-1,CG.inst.height-hh-CG.inst.button_font.getHeight()-3,10,
                    CG.inst.First_text_FontSize,CG.inst.First_text_FontStyle,CG.inst.First_text_FontType,g,
                    text,true);
            isFirstRun=false;
       }
       g.setColor(CG.inst.First_text_textcolor);
       MLT.DrawMultStr();
    }

    public void keyPressed(int key){
       if (key==1) {
           MLT.MoveUp();
       }else if (key==6){
           MLT.MoveDown();
       }else if (key==2){
           MLT.PageUp();
       }else if (key==5){
           MLT.PageDown();
       }else if (key==-6){
           ScreenCanvas.inst.set_current_canvas(SAbout.inst);
       }else if (key==-7 || key==-8){
           if (MyLocate.inst.get_city().equals("-1")) ScreenCanvas.inst.set_current_canvas(SLocate.inst);
           else ScreenCanvas.inst.set_current_canvas(SMain.inst);
       }
    }

    public void setActive(){
        hh=CG.inst.beg_string_font.getHeight()+ CG.inst.title_string_font.getHeight()+6;
    }

    public void load_data(String text){
        this.text=text;
        isFirstRun=true;
    }
}
