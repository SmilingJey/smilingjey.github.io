package ru.jcod.mobcatalog.data;


import ru.jcod.mobcatalog.*;
import ru.jcod.mobcatalog.ui.SVac;
import ru.jcod.mobcatalog.ui.SNames;
import ru.jcod.mobcatalog.ui.SSearch;
import ru.jcod.mobcatalog.ui.SSubCat;
import ru.jcod.mobcatalog.ui.SObiav_add;
import ru.jcod.mobcatalog.ui.SCat;
import ru.jcod.mobcatalog.ui.SContent;
import ru.jcod.mobcatalog.ui.SObiav;
import ru.jcod.mobcatalog.ui.ScreenCanvas;
import ru.jcod.mobcatalog.ui.SObiav_list;
import ru.jcod.mobcatalog.net.Net_connect;

public class MyData {

    public static MyData inst;
    public MyData(){
        inst=this;
        table=new MyTable();
    }

    //-----------------------�����-----------------------------------------
    public MyTable table;
    int city=-1;
    int cat=-1;
    public int subcat=-1;
    public int page=-1;
    int name=-1;



    public void load_cat(int city){
        if (table.empty() || city!=this.city){
           table.clear();
           Net_connect.inst.send("<cat city_id="+city+"></cat>");
           this.city=city;
        }else{
           SCat.inst.load_data(table);
        }
    }

    public void load_subcat(int cat,int city){
        int id_cat=table.col1.indexOf(Integer.toString(cat));
        if (id_cat!=-1){
            if (table.col3.elementAt(id_cat)!=null){
                SSubCat.inst.load_data(table.get_col3(id_cat));
            }else{
                table.set_col3(new MyTable(), id_cat);
                Net_connect.inst.send("<subcat cat_id="+cat+" city_id="+city+"></subcat>");
            }
        }
        this.cat=cat;
    }

    public void load_names(int subcat,int city_id,int page){
        this.page=page;
        this.subcat=subcat;
        if (city==city_id){
            int id_cat=table.col1.indexOf(Integer.toString(cat));
            if (id_cat!=-1){
                int id_subcat=table.get_col3(id_cat).col1.indexOf(Integer.toString(subcat));
                if (id_subcat!=-1){
                    if(table.get_col3(id_cat).get_col3(id_subcat)==null)
                                table.get_col3(id_cat).set_col3(new MyTable(),id_subcat);
                    int id_page=table.get_col3(id_cat).get_col3(id_subcat).col1.indexOf(Integer.toString(page));
                     
                    if (id_page!=-1){
                        SNames.inst.load_data(table.get_col3(id_cat).get_col3(id_subcat).get_col3(id_page));
                    }else{
                        table.get_col3(id_cat).get_col3(id_subcat).add(Integer.toString(page), null,new MyTable());
                        Net_connect.inst.send("<names sub_id="+subcat+" city_id="+city_id+" page_id="
                                +page+" page_size="+Config.inst.get_page_size()+"></names>");
                    }
                }
            }
        }
    }

    public void load_info(int name){
        if (SNames.inst.search){
            Net_connect.inst.send("<info name_id="+name+"></info>");
        }else{
            this.name=name;
            int id_cat=table.col1.indexOf(Integer.toString(cat));
            if (id_cat==-1) return;
            int id_subcat=table.get_col3(id_cat).col1.indexOf(Integer.toString(subcat));
            if (id_subcat==-1) return;
            int id_page=table.get_col3(id_cat).get_col3(id_subcat).col1.indexOf(Integer.toString(page));
            if (id_page==-1) return;
            int id_name=table.get_col3(id_cat).get_col3(id_subcat).get_col3(id_page).col1.indexOf(Integer.toString(name));
            if (id_name==-1) return;
            if (table.get_col3(id_cat).get_col3(id_subcat).get_col3(id_page).get_col3(id_name)!=null){
                SContent.inst.load_data(table.get_col3(id_cat).get_col3(id_subcat)
                                                                            .get_col3(id_page).get_col3(id_name));
            }else{
                table.get_col3(id_cat).get_col3(id_subcat).get_col3(id_page).set_col3(new MyTable(), id_name);
                Net_connect.inst.send("<info name_id="+name+"></info>");
            }
        }
    }

    public MyTable get_table_subcat(){
        return table.get_col3(table.col1.indexOf(Integer.toString(cat)));
    }

    public MyTable get_table_names(){
        MyTable pages=get_table_subcat().get_col3(get_table_subcat().col1.indexOf(Integer.toString(subcat)));
        return pages.get_col3(pages.col1.indexOf(Integer.toString(page)));
    }

    public MyTable get_table_info(){
        MyTable pages=get_table_subcat().get_col3(get_table_subcat().col1.indexOf(Integer.toString(subcat)));
        MyTable names=pages.get_col3(pages.col1.indexOf(Integer.toString(page)));
        return names.get_col3(names.col1.indexOf(Integer.toString(name)));
    }

    //----------------------------�����-------------------------------------------

    public String search_s;
    String Srch;
    int search_city;
    public int search_page;
    MyTable search_table;
    MyTable search_content;

    public void load_search(int search_city,String search_s,String Srch,int search_page,String end_tag){
        if (search_city!=this.search_city || !search_s.equals(this.search_s) || !Srch.equals(this.Srch) || search_table==null){
            search_table=new MyTable();
            search_table.add(Integer.toString(search_page), null, new MyTable());
            this.search_city=search_city;
            this.search_s=search_s;
            this.Srch=Srch;
            this.search_page=search_page;
            Net_connect.inst.send("<"+Srch+" city_id="+search_city+" string=\""+toAnsi(search_s)+
                                            "\" page_id="+search_page+" page_size="
                                            +Config.inst.get_page_size()+"></"+Srch+">");
        }
        else{
            int p=search_table.col1.indexOf(Integer.toString(search_page));
            if (p!=-1){
                if (SSearch.inst.radiobutton_select==0){
                    SNames.inst.load_data(search_table.get_col3(p));
                }else if  (SSearch.inst.radiobutton_select==1){
                    SVac.inst.load_data(search_table.get_col3(p));
                }else if  (SSearch.inst.radiobutton_select==2){
                    SObiav_list.inst.load_data(search_table.get_col3(p));
                }
            }else{
                search_table.add(Integer.toString(search_page), null, new MyTable());
                this.search_page=search_page;
                Net_connect.inst.send("<"+Srch+" city_id="+search_city+" string=\""+toAnsi(search_s)+
                                            "\" page_id="+search_page+" page_size="
                                            +Config.inst.get_page_size()+"></"+Srch+">");
            }
        }
    }

    public MyTable get_table_search(){
        return search_table.get_col3(search_table.col1.indexOf(Integer.toString(search_page)));
    }

    public MyTable get_table_search_content(){
        return search_content;
    }

    public MyTable table_prof=null;

    //----------------------���������--------------------------------

    public void load_prof(){
        if (table_prof!=null){
            SCat.inst.load_data(table_prof);
        }else{
            Net_connect.inst.send("<prof></prof>");
        }
    }

    public int vac_page;
    public int vac_prof;
    int vac_full;

    public void load_vac_list(int prof_id,int page_id){
        vac_page=page_id;
        vac_prof=prof_id;
        int prof=table_prof.col1.indexOf(Integer.toString(prof_id));
        if (prof!=-1){
            if (table_prof.get_col3(prof)==null) table_prof.set_col3(new MyTable(), prof);
            int page_vac=table_prof.get_col3(prof).col1.indexOf(Integer.toString(page_id));
            if (page_vac!=-1){
                SVac.inst.load_data(table_prof.get_col3(prof).get_col3(page_vac));
            }else{
                table_prof.get_col3(prof).add(Integer.toString(page_id),null , new MyTable());
                Net_connect.inst.send("<vacancy city_id="+MyLocate.inst.get_city()+
                            " prof_id="+prof_id+" page_id="+vac_page+" page_size="
                            +Config.inst.get_page_size()+"></vacancy>");
            }
        }
    }

    public void load_vac(int vac){
        if (SVac.inst.search){
            Net_connect.inst.send("<vac_info id="+vac+"></vac_info>");
        }else{
            vac_full=vac;
            int prof=table_prof.col1.indexOf(Integer.toString(vac_prof));
            if (prof==-1) return;
            int page_vac=table_prof.get_col3(prof).col1.indexOf(Integer.toString(vac_page));
            if (page_vac==-1) return;
            int vac_id=table_prof.get_col3(prof).get_col3(page_vac).col1.indexOf(Integer.toString(vac));
            if (vac_id==-1) return;
            if (table_prof.get_col3(prof).get_col3(page_vac).get_col3(vac_id)!=null){
                SContent.inst.load_data(table_prof.get_col3(prof).get_col3(page_vac).get_col3(vac_id));
            }else {
                table_prof.get_col3(prof).get_col3(page_vac).set_col3(new MyTable(),vac_id);
                Net_connect.inst.send("<vac_info id="+vac+"></vac_info>");
            }
        }
    }

    public MyTable get_table_vacfull(){
        int prof=table_prof.col1.indexOf(Integer.toString(vac_prof));
        int page_vac=table_prof.get_col3(prof).col1.indexOf(Integer.toString(vac_page));
        int vac_full_id=table_prof.get_col3(prof).get_col3(page_vac).col1.indexOf(Integer.toString(vac_full));
        return table_prof.get_col3(prof).get_col3(page_vac).get_col3(vac_full_id);
    }

    public MyTable get_table_vac_list(){
        int prof=table_prof.col1.indexOf(Integer.toString(vac_prof));
        int page_vac=table_prof.get_col3(prof).col1.indexOf(Integer.toString(vac_page));
        if (prof!=-1 && page_vac!=-1) return table_prof.get_col3(prof).get_col3(page_vac);
        else return new MyTable();
    }

    //---------------����������-----------------------------------------

    public MyTable table_sec;
    public int sec_selected_id=-1;

    public void load_table_sec(){
        if (table_sec!=null){
            //SObiav.inst.loadlist(table_sec);
            if (ScreenCanvas.inst.current_canvas.equals(SObiav.inst)) SObiav.inst.loadlist(table_sec);
            else SObiav_add.inst.loadlist(table_sec);
        }else {
            Net_connect.inst.send("<sec></sec>");
        }
    }

    public int subsec_selected_id=-1;

    public void load_table_sucsec(int sec){
        int sec_id=table_sec.col1.indexOf(Integer.toString(sec));
        if (table_sec.get_col3(sec_id)!=null){
            //SObiav.inst.loadlist(table_sec.get_col3(sec_id));
            if (ScreenCanvas.inst.current_canvas.equals(SObiav.inst)) SObiav.inst.loadlist(table_sec.get_col3(sec_id));
            else SObiav_add.inst.loadlist(table_sec.get_col3(sec_id));
        }else{
            Net_connect.inst.send("<subsec sec_id="+sec+"></subsec>");
        }
    }

    public MyTable get_table_subsec(){
        return table_sec.get_col3(sec_selected_id);
    }

    public int get_sec(){
        if (sec_selected_id==-1) return -1;
        if (subsec_selected_id==-1) return table_sec.get_col1(sec_selected_id);
        else return table_sec.get_col3(sec_selected_id).get_col1(subsec_selected_id);
    }

    public int get_subsec(){
        if (sec_selected_id==-1 || subsec_selected_id==-1) return -1;
        else return table_sec.get_col3(sec_selected_id).get_col1(subsec_selected_id);
    }

    public MyTable ob_pages;
    public int ob_page=-1;
    public int ob_city=-1;
    public int ob_sec=-1;
    public int ob_ann_full=-1;
    public String ob_filter="";

    public void load_table_ann(int obpage,int city,int sec,String filter){
        ob_page=obpage;
        if (city!=ob_city || sec!=ob_sec  || !filter.equals(ob_filter)){
            ob_pages=new MyTable();
            ob_city=city;
            ob_sec=sec;
            ob_filter=filter;
            Net_connect.inst.send("<ann city_id="+city+" sec_id="+sec+" string=\""+
                    toAnsi(filter)+"\" page_id="+obpage+" page_size="+Config.inst.get_page_size()+"></ann>");
        }else{
            int obpage_id=ob_pages.col1.indexOf(Integer.toString(obpage));
            if (obpage_id!=-1){
                SObiav_list.inst.load_data(ob_pages.get_col3(obpage_id));
            }else{
                Net_connect.inst.send("<ann city_id="+city+" sec_id="+sec+" string=\""+
                    toAnsi(filter)+"\" page_id="+obpage+" page_size="+Config.inst.get_page_size()+"></ann>");
            }
        }
    }

    public void load_table_ann_full(int annid){
        if (SObiav_list.inst.search){
            Net_connect.inst.send("<ann_info id="+annid+"></ann_info>");
        }else{
            ob_ann_full=annid;
            int obpage_id=ob_pages.col1.indexOf(Integer.toString(ob_page));
            if (obpage_id==-1) return;
            int ann_full_id=ob_pages.get_col3(obpage_id).col1.indexOf(Integer.toString(annid));
            if (ann_full_id==-1) return;
            if (ob_pages.get_col3(obpage_id).get_col3(ann_full_id)!=null){
                 SContent.inst.load_data(ob_pages.get_col3(obpage_id).get_col3(ann_full_id));
            }else{
                 Net_connect.inst.send("<ann_info id="+annid+"></ann_info>");
            }
        }
    }

    public static String toAnsi(String s) {
        byte[] array = s.getBytes();

        for(int i = 0, n = s.length(); i < n; i++) {
          char c;

          switch (c = s.charAt(i)) {
          case 1025: array[ i ] = -88; break;
          case 1105: array[ i ] = -72; break;
          case 1168: array[ i ] = -91; break;
          case 1028: array[ i ] = -86; break;
          case 1031: array[ i ] = -81; break;
          case 1030: array[ i ] = -78; break;
          case 1110: array[ i ] = -77; break;
          case 1169: array[ i ] = -76; break;
          case 1108: array[ i ] = -70; break;
          case 1111: array[ i ] = -65; break;
          default:
            if(c >= '\u0410' && c <= '\u044F')
              array[ i ] = (byte)((c - 1040) + 192);
          }
        }
        return new String(array);
     }
}
