package ru.jcod.mobcatalog.ui;

import ru.jcod.mobcatalog.data.MyTable;
import ru.jcod.mobcatalog.data.MyData;
import ru.jcod.mobcatalog.data.MyLocate;
import ru.jcod.mobcatalog.*;
import javax.microedition.lcdui.Graphics;

public class SNames implements ICanvas{

    public static SNames inst;
    private String title="�������� ";
    private String leftbutton[]={"�����"};
    private String rightbutton[]={"������","�����","��.����"};
    private boolean show_leftbutton=false;
    private boolean show_rightbutton=false;
    private int active_button=0;
    int active_menu_item=0;
    private MyTable table=null;
    public boolean load_data=false;
    public boolean search=false;
    boolean namenapr=false;
    private int namescroll=0;
    private long name_oldticker;
    private int namescroll_active=-1;
    private int h0,h1,hh,fullh,menu_width,yadd,hpp,i,e,indexof,fw1,fw2,xs1,xs2;
    private boolean menu_scroll;
    private String s1="";
    private String s2="";

    public void initlistscroll(int a){
        if (namescroll_active!=a){
            name_oldticker=CG.inst.ticker_count;
            namenapr=false;
            namescroll=0;
            namescroll_active=a;
        }
    }

    public SNames(){
        inst = this;
    }

    public void paint(Graphics g) {
       CG.p_beg_string(g);
       if (search) title="�����, �������� "+MyData.inst.search_page;
       else title="�������� "+(int)(MyData.inst.page);
       if (table!=null) title=title+"/"+table.table_prop1;
       CG.p_title(g,title,true);
       if (load_data) CG.p_wait(g);
       else if (table==null) CG.p_nodata(g);
       else if (table.size()<=0) CG.p_nodata(g);
       else p_menu(g);
       CG.p_button(g, null, rightbutton, false, show_rightbutton, active_button, "�����", "�������");
   }

   public void p_menu(Graphics g){
        g.setClip(0, h0, CG.inst.width, fullh);
        yadd=0;
        if ((active_menu_item+1)*hh>fullh) yadd=(active_menu_item+1)*hh-fullh+1;
        i=yadd/hh-1<0?0:yadd/hh-1;
        e=(fullh+yadd)/hh+1>table.size()?table.size():(fullh+yadd)/hh+1;
        indexof=-1;
        for(;i<e;i++){
            indexof=table.get_col2(i).indexOf("\n");
            if (indexof!=-1){
                s1=table.get_col2(i).substring(0, indexof);
                s2=table.get_col2(i).substring(indexof+1);
            }else {
                s1=table.get_col2(i);
                s2="";
            }
            if (i==active_menu_item) g.setColor(CG.inst.active_item_background);
            else g.setColor(CG.inst.menu_item_background);
            g.fillRect(0, h0+i*hh-yadd, menu_width,hh);
            fw1=CG.inst.menu_font_big.stringWidth(s1);
            fw2=CG.inst.menu_font.stringWidth(s2);
            xs1=0;
            xs2=0;
            if (i==active_menu_item){
                g.setColor(CG.inst.active_textcolor);
                initlistscroll(i);
                if (CG.inst.width>fw1 && CG.inst.width>fw2){
                }else{
                    if ((CG.inst.width<fw1 && CG.inst.width>fw2)||(CG.inst.width<fw1 && CG.inst.width<fw2 && fw1>=fw2)){
                        namenapr=CG.get_napr(namescroll,fw1+5-CG.inst.width,namenapr);
                        namescroll=CG.inst.get_scrollx(namescroll,namenapr,name_oldticker,CG.inst.text_scroll_speed);
                        xs1=namescroll;
                        name_oldticker=CG.inst.ticker_count;
                    } else{
                        namenapr=CG.get_napr(namescroll,fw2+5-CG.inst.width,namenapr);
                        namescroll=CG.inst.get_scrollx(namescroll,namenapr,name_oldticker,CG.inst.text_scroll_speed);
                        xs1=namescroll;
                        name_oldticker=CG.inst.ticker_count;
                    }
                }
            }else g.setColor(CG.inst.menu_textcolor);
            g.setFont(CG.inst.menu_font_big);
            g.drawString(s1,5+xs1,h0+i*hh+2-yadd, Graphics.LEFT | Graphics.TOP);
            g.setFont(CG.inst.menu_font);
            g.drawString(s2,5+xs1,h0+i*hh+h1+2-yadd, Graphics.LEFT | Graphics.TOP);
            g.setColor(CG.inst.menu_item_border);
            g.drawRect(0, h0+i*hh-yadd, menu_width-1,hh);
       }
       if (menu_scroll){
           g.setColor(CG.inst.scroll_color);
           g.fillRect(CG.inst.width-CG.inst.scroll_width, h0, CG.inst.scroll_width,fullh);
           g.setColor(CG.inst.scroll_pols);
           hpp=(int)(fullh/(table.size()));if (hpp<2) hpp=3;
           g.fillRect(CG.inst.width-CG.inst.scroll_width, h0+(int)(active_menu_item*fullh/table.size()), CG.inst.scroll_width, hpp);
        }
        g.setClip(0, 0, CG.inst.width, CG.inst.height);
    }

    public void keyPressed( int key){
       if (key == 1) {
            if (show_leftbutton || show_rightbutton){
                if (active_button!=(show_leftbutton?leftbutton.length-1:rightbutton.length-1)) active_button++;
                else active_button=0;
            }else{
                if (!load_data && table!=null && !table.empty()){
                    if (active_menu_item!=0) active_menu_item--;
                    else active_menu_item=table.size()-1;
                }
            }
       }else if (key == 6){
            if (show_leftbutton || show_rightbutton){
                if (active_button!=0) active_button--;
                else active_button=show_leftbutton?leftbutton.length-1:rightbutton.length-1;
            }else{
                if (!load_data && table!=null && !table.empty()){
                    if (active_menu_item!=table.size()-1) active_menu_item++;
                    else active_menu_item=0;
                }
            }
       }else if (key == -6){
              if (search)ScreenCanvas.inst.set_current_canvas(SSearch.inst);
              else ScreenCanvas.inst.set_current_canvas(SSubCat.inst);
       }else if (key == -7){
           if (rightbutton.length>1){
               show_rightbutton=!show_rightbutton;
               active_button=0;
           }
       }else if (key == 2){
               if (search){
                   if (MyData.inst.search_page>1 && table!=null){
                        load_data=true;
                        MyData.inst.search_page--;
                        MyData.inst.load_search(Integer.parseInt(MyLocate.inst.get_city())
                                    ,MyData.inst.search_s, "nameSrch",MyData.inst.search_page,"names_list");
                   }
               }else{
                   if (MyData.inst.page>1 && table!=null){
                        load_data=true;
                        MyData.inst.page--;
                        MyData.inst.load_names(MyData.inst.subcat,
                                             Integer.parseInt(MyLocate.inst.get_city()),MyData.inst.page);
                   }
               }
       }else if (key == 5){
           if (search){
                if (table!=null){
                    if (MyData.inst.search_page<table.table_prop1){
                        load_data=true;
                        MyData.inst.search_page++;
                        MyData.inst.load_search(Integer.parseInt(MyLocate.inst.get_city())
                                ,MyData.inst.search_s, "nameSrch",MyData.inst.search_page,"names_list");
                    }
                }
           }else{
                if (table!=null){
                    if (MyData.inst.page<table.table_prop1){
                        load_data=true;
                        MyData.inst.page++;
                        MyData.inst.load_names(MyData.inst.subcat,
                                     Integer.parseInt(MyLocate.inst.get_city()),MyData.inst.page);
                    }
                }
           }
       }else if (key == -8){
           if(show_leftbutton){
               show_leftbutton=false;
               active_button=0;
           }else if(show_rightbutton){
               if (active_button==1){
                   MobileCatalog.quitApp();
               } else if (active_button==2){
                   ScreenCanvas.inst.set_current_canvas(SMain.inst);
               }
               show_rightbutton=false;
               active_button=0;
           } else{
              if (!load_data && table!=null && !table.empty()){
                SContent.inst.load_data=true;
                SContent.inst.data_type=0;
                MyData.inst.load_info(table.get_col1(active_menu_item));
                ScreenCanvas.inst.set_current_canvas(SContent.inst);
              }
           }
       }
       CG.inst.text_x=5;
    }

    public void load_data(MyTable table){
        active_menu_item=0;
        this.table=table;
        menu_scroll=(hh*table.size()>fullh);
        if (menu_scroll) menu_width=CG.inst.width-CG.inst.scroll_width;
        load_data=false;
        ScreenCanvas.inst.repaint();
    }

    public void setActive(){
        initlistscroll(-1);
        h0=CG.inst.beg_string_font.getHeight()+ CG.inst.title_string_font.getHeight()+6;
        h1=CG.inst.menu_font.getHeight();
        hh=CG.inst.menu_font.getHeight()*2+3;
        fullh=CG.inst.height-h0-CG.inst.button_font.getHeight()-3;
        menu_width=CG.inst.width;
    }
}
