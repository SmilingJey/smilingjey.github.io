package ru.jcod.mobcatalog;

import javax.microedition.lcdui.Canvas;
import javax.microedition.lcdui.Display;
import ru.jcod.mobcatalog.data.MyData;
import ru.jcod.mobcatalog.data.MyLocate;
import ru.jcod.mobcatalog.ui.SImage;
import ru.jcod.mobcatalog.ui.SSubCat;
import ru.jcod.mobcatalog.ui.SObiav_add_load;
import ru.jcod.mobcatalog.ui.SLocate;
import ru.jcod.mobcatalog.ui.CG;
import ru.jcod.mobcatalog.ui.SObiav_add;
import ru.jcod.mobcatalog.ui.SCat;
import ru.jcod.mobcatalog.ui.SObiav;
import ru.jcod.mobcatalog.ui.ScreenCanvas;
import ru.jcod.mobcatalog.ui.SObiav_list;
import ru.jcod.mobcatalog.ui.SVac;
import ru.jcod.mobcatalog.ui.SSearch;
import ru.jcod.mobcatalog.ui.SNames;
import ru.jcod.mobcatalog.ui.SMain;
import ru.jcod.mobcatalog.ui.SAbout;
import ru.jcod.mobcatalog.ui.Search_inputbox;
import ru.jcod.mobcatalog.ui.SContent;
import ru.jcod.mobcatalog.ui.SFirst;
import ru.jcod.mobcatalog.net.Net_connect;
import javax.microedition.midlet.MIDlet;
import ru.jcod.mobcatalog.net.Alive;
import ru.jcod.mobcatalog.net.Parser;
import ru.jcod.mobcatalog.ui.SConnect;

public class MobileCatalog extends MIDlet{

    public static MobileCatalog inst;
    private ScreenCanvas sc;
    private Net_connect nc;
    private Config cf;
    private Alive alive;

    public MobileCatalog() {
       inst = this;
       cf=new Config(this);
       new CG();
       new MyData();
       new SFirst();
       new SMain();
       new SCat();
       new SSubCat();
       new SNames();
       new SVac();
       new SContent();
       new SImage();
       new SSearch();
       new SObiav();
       new SObiav_add();
       new SObiav_add_load();
       new SObiav_list();
       new MyLocate();
       new SLocate();
       new SAbout();
       new Parser();
       new Search_inputbox();
       nc=new Net_connect();
       alive=new Alive();
       sc=new ScreenCanvas();
       sc.set_current_canvas(SFirst.inst);
    }

    public void set_screancanvas(){
        Display.getDisplay(this).setCurrent(sc);
        CG.setFullScreenMode((Canvas)sc,true);
        sc.set_current_canvas(sc.current_canvas);
        CG.setFullScreenMode((Canvas)sc,true);
    }

    public void startApp() {
       Display.getDisplay(this).setCurrent(new SConnect());
       cf.loadconf();
       SConnect.inst.set_load(1);
       (new Thread(nc)).start();
       (new Thread(alive)).start();
    }

    public void pauseApp() {

    }

    public void destroyApp(boolean unconditional) {

    }

    public static void quitApp() {
        Config.inst.saveconf();
        inst.destroyApp(true);
        inst.notifyDestroyed();
        inst = null;
    }

}
