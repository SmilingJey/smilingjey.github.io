package ru.jcod.mobcatalog.ui;

import ru.jcod.mobcatalog.*;
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.CommandListener;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.TextBox;


public class Search_inputbox extends TextBox implements CommandListener {

    static Search_inputbox inst;

    private ICanvas back_canvas;
    private Command cOK;
    private String parametr;

    public Search_inputbox() {
        super("������� �����",null, 500, 0);
        inst = this;
        init();
    }

    private void init(){
        cOK=new Command("OK", Command.OK, 1);
        addCommand(cOK);
        setCommandListener(this);
    }

    public void show(ICanvas back_canvas,String title,String parametr){
        this.back_canvas=back_canvas;
        setTitle(title);
        this.parametr=parametr;
        setString("");
        Display.getDisplay(MobileCatalog.inst).setCurrent(this);
    }

    public void commandAction(Command command, Displayable displayable) {
        if (command.equals(cOK)) {
            if (back_canvas.equals(SSearch.inst)) SSearch.inst.search_text=this.getString().trim();
            else if (back_canvas.equals(SObiav.inst)) SObiav.inst.filtr_text=this.getString().trim();
            else if (back_canvas.equals(SObiav_add.inst)){
                if (parametr.equals("adres")) SObiav_add.inst.adres=this.getString().trim();
                else if (parametr.equals("phone")) SObiav_add.inst.phone=this.getString().trim();
                else if (parametr.equals("cost")) SObiav_add.inst.cost=this.getString().trim();
                else if (parametr.equals("shorttext")) SObiav_add.inst.shorttext=this.getString().trim();
                else if (parametr.equals("fulltext")) {
                    SObiav_add.inst.fulltext=this.getString().trim();
                }else if (parametr.equals("captcha")) SObiav_add.inst.captcha=this.getString().trim();
            }
            ScreenCanvas.inst.current_canvas=back_canvas;
            MobileCatalog.inst.set_screancanvas();
        }
    }
}
