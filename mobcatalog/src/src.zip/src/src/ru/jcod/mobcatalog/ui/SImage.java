package ru.jcod.mobcatalog.ui;

import ru.jcod.mobcatalog.net.Net_connectFile;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;

public class SImage implements ICanvas{

    public static SImage inst;

    private Image img;
    private Image img_back;
    String leftbutton[]={};
    String rightbutton[]={"������","���������","���������","��.����"};
    boolean show_leftbutton=false;
    boolean show_rightbutton=false;
    int active_button=0;
    public boolean load_data=false;
    int hh=0,fullh,hpp, fh, ximg=0,yimg=0, h,w;
    String title="����� �������";
    boolean hscroll,wscroll;
    private int scale=100;

    public SImage(){
        inst = this;
    }

    public void paint(Graphics g) {
       hh=CG.inst.beg_string_font.getHeight()+ CG.inst.title_string_font.getHeight()+6;
       fullh=CG.inst.height-hh-CG.inst.button_font.getHeight()-3;

       if (load_data){
           CG.p_wait(g);
           fh=CG.inst.get_text_font().getHeight();
           if (Net_connectFile.inst!=null){
               CG.p_progressbar(g,10,hh+fh+10,CG.inst.width-20,fh,Net_connectFile.inst.file_get(),
                                                 Net_connectFile.inst.file_size(), "byte", true);
           }
       }else{
           p_image(g);
           if (scale!=100){
               g.setFont(CG.inst.get_text_font());
               g.setColor(0xff0000);
               g.drawString("������� "+scale+"%",CG.inst.width,hh, Graphics.RIGHT | Graphics.TOP);
           }
       }

       CG.p_beg_string(g);
       title="����� �������";
       CG.p_title(g,title,false);
       CG.p_button(g, leftbutton, rightbutton, show_leftbutton, show_rightbutton, active_button,"�����","�������");
    }

    public void p_image(Graphics g){
        g.drawImage(img, -ximg,-yimg, Graphics.LEFT | Graphics.TOP);
        if (wscroll){
           g.setColor(CG.inst.scroll_color);
           g.fillRect(0,hh+fullh- CG.inst.scroll_width,CG.inst.width, CG.inst.scroll_width);
           g.setColor(CG.inst.scroll_pols);
           hpp=(CG.inst.width*CG.inst.width/w);
           g.fillRect(CG.inst.width*ximg/w, hh+fullh- CG.inst.scroll_width, hpp,CG.inst.scroll_width );
        }
        if (hscroll){
           g.setColor(CG.inst.scroll_color);
           g.fillRect(CG.inst.width-CG.inst.scroll_width,hh, CG.inst.scroll_width,fullh);
           g.setColor(CG.inst.scroll_pols);
           hpp=(fullh*fullh/h);
           g.fillRect(CG.inst.width-CG.inst.scroll_width, hh+fullh*yimg/h, CG.inst.scroll_width, hpp);
        }
    }

    public void keyPressed(int key){
       if (key == 1)       {
            if (show_leftbutton || show_rightbutton){
                if (active_button!=(show_leftbutton?leftbutton.length-1:rightbutton.length-1)) active_button++;
                else active_button=0;
            }else{
                if (hscroll){
                   if (yimg>=0) yimg-=5;
                }
            }
       }else if (key == 6){
            if (show_leftbutton || show_rightbutton){
                if (active_button!=0) active_button--;
                else active_button=show_leftbutton?leftbutton.length-1:rightbutton.length-1;
            }else{
                if (hscroll){
                    if (yimg<h-fullh) yimg+=5;
                  
                }
            }
       }else if (key == -6){
           if (leftbutton.length>1){
               show_leftbutton=!show_leftbutton;
               active_button=0;
           }else{
                  ScreenCanvas.inst.set_current_canvas(SContent.inst);
           }
       }else if (key == -7){
           if (rightbutton.length>1){
               show_rightbutton=!show_rightbutton;
               active_button=0;
           }else{
               
           }
       }else if (key == 2){
            if (wscroll){
                if (ximg>=0) ximg-=5;
            }
       }else if (key == 5){
            if (wscroll){
                if (ximg<w-CG.inst.width) ximg+=5;
            }
       }else if (key == -8){
           if(show_leftbutton){
               if (active_button==0){

               }
               show_leftbutton=false;
               active_button=0;
           }else if(show_rightbutton){
               if (active_button==1){
                   if (scale>20){
                       scale=scale-20;
                       if ( scale==100 ) img=img_back;
                       else img=scale(img_back, scale*w/100, scale*h/100);
                       init_img();
                   }
               }else if (active_button==2){
                   if (scale<200){
                       scale=scale+20;
                       if ( scale==100 ) img=img_back;
                       else img=scale(img_back, scale*w/100, scale*h/100);
                       init_img();
                   }
               }else if (active_button==3){
                    ScreenCanvas.inst.set_current_canvas(SMain.inst);
               }
               show_rightbutton=false;
               active_button=0;
           } else{

           }
       }
    }

    public void load_data(byte[] b){
        img_back=Image.createImage(b, 0, b.length);
        img=img_back;
        init_img();
        load_data=false;
    }

    public void init_img(){
        h=img.getHeight();
        w=img.getWidth();
        yimg=hh;
        ximg=w/2;
        hscroll=h>fullh;
        wscroll=w>CG.inst.width;
    }

    private Image scale(Image src, int screenWidth, int screenHeight) {
      int srcWidth = src.getWidth();
      int srcHeight = src.getHeight();
      Image tmp = Image.createImage(screenWidth, srcHeight);
      Graphics g = tmp.getGraphics();
      int ratio = (srcWidth << 16) / screenWidth;
      int pos = ratio/2;

      //Horizontal Resize

      for (int x = 0; x < screenWidth; x++) {
          g.setClip(x, 0, 1, srcHeight);
          g.drawImage(src, x - (pos >> 16), 0, Graphics.LEFT | Graphics.TOP);
          pos += ratio;
      }

      Image resizedImage = Image.createImage(screenWidth, screenHeight);
      g = resizedImage.getGraphics();
      ratio = (srcHeight << 16) / screenHeight;
      pos = ratio/2;

      //Vertical resize

      for (int y = 0; y < screenHeight; y++) {
          g.setClip(0, y, screenWidth, 1);
          g.drawImage(tmp, 0, y - (pos >> 16), Graphics.LEFT | Graphics.TOP);
          pos += ratio;
      }
      return resizedImage;

  }

    /*public static Image scale(Image original, int newWidth, int newHeight){
        int[] rawInput = new int[original.getHeight() * original.getWidth()];
        original.getRGB(rawInput, 0, original.getWidth(), 0, 0, original.getWidth(), original.getHeight());

        int[] rawOutput = new int[newWidth*newHeight];

        // YD compensates for the x loop by subtracting the width back out
        int YD = (original.getHeight() / newHeight) * original.getWidth() - original.getWidth();
        int YR = original.getHeight() % newHeight;
        int XD = original.getWidth() / newWidth;
        int XR = original.getWidth() % newWidth;
        int outOffset= 0;
        int inOffset=  0;

        for (int y= newHeight, YE= 0; y > 0; y--) {
            for (int x= newWidth, XE= 0; x > 0; x--) {
                rawOutput[outOffset++]= rawInput[inOffset];
                inOffset+=XD;
                XE+=XR;
                if (XE >= newWidth) {
                    XE-= newWidth;
                    inOffset++;
                }
            }
            inOffset+= YD;
            YE+= YR;
            if (YE >= newHeight) {
                YE -= newHeight;
                inOffset+=original.getWidth();
            }
        }
        return Image.createRGBImage(rawOutput, newWidth, newHeight, false);
    }*/

    /*public Image scale(Image image, int w, int h) {
        int w0 = image.getWidth();
        int h0 = image.getHeight();
        int[] arrayOld = new int[w0*h0];
        int[] arrayNew = new int[w*h];
        image.getRGB(arrayOld, 0, w0, 0, 0, w0, h0);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                 arrayNew[x+w*y] = arrayOld[x*w0/w+w0*(int)(y*h0/h)];
            }
        }
        return Image.createRGBImage(arrayNew, w, h, true);
    }*/

    public void setActive(){

    }
}
