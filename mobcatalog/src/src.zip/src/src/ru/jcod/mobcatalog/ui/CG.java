package ru.jcod.mobcatalog.ui;

import ru.jcod.mobcatalog.*;
import java.util.Timer;
import java.util.TimerTask;
import java.util.Vector;
import javax.microedition.lcdui.Canvas;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Font;
import javax.microedition.lcdui.Graphics;
import ru.jcod.mobcatalog.net.Net_connect;
import ru.jcod.mobcatalog.net.Parser;
import ru.jcod.mobcatalog.ui.SConnect;

public class CG {

    public static CG inst;

    public int width=1;
    public int height=1;
    public CG(){
        inst=this;
        timer.schedule(mover, 0,100);
    }

    /*-------------------����� ��� ��������---------------*/
    public String load_text="�������� ������ ";
    public String load_nodata="������ ���";
    /*---------------------���� ����-------------------------*/
    public int background=0xDDDDDDD;
    /* ---------------������� ������ -------------------------*/
    Timer timer=new Timer();
    FieldMover mover = new FieldMover();
    int beg_string_x=15;
    int beg_string_speed=3;
    int text_scroll_speed=2;
    int text_x=5;
    int text_width=0;
    boolean napr=true;
    long ticker_count;
    int si;
    String dots;

    class FieldMover extends TimerTask {
        public void run(){
            beg_string_x=beg_string_x-3;
            if (beg_string_x<=-CG.inst.get_beg_string_width()-30) beg_string_x=0;
            ticker_count++;

            if (text_width<=width) text_x=5;
            else {
                if (napr) {
                    text_x=text_x-text_scroll_speed;
                    if (-text_x>text_width+10-width) napr=false;
                }else{
                    text_x=text_x+text_scroll_speed;
                    if (text_x-5>=5) napr=true;
                }
           }

           si++;
           if (si==1) dots=".";
           else if (si==8) dots=". .";
           else if (si==16) dots=". . .";
           else if (si==24) dots="";
           else if (si==32) si=0;

           if ( ScreenCanvas.inst!=null) ScreenCanvas.inst.repaint();
           if (SConnect.inst!=null && SConnect.inst.isShown()) SConnect.inst.repaint();
        }
    }

    public int get_scrollx(int x,boolean napr,long old_ticker,int speed){
        if (napr){
            x=x+(int)(speed*(ticker_count-old_ticker));
        }else{
            x=x-(int)(speed*(ticker_count-old_ticker));
        }
        return x;
    }
    
    public static boolean get_napr(int x,int w,boolean n){
        if (n && x>0) return false;
        if (!n && x<-5-w) return true;
        return n;
    }

    public static void setFullScreenMode(Canvas c,boolean b){
        //#if MIDP == "1.0"
        
        //#else
//#         c.setFullScreenMode(b);
        //#endif
    }

    public String beg_string="��������� ������� - ���������� �� ������������, ������� ��� �������, �������� � ����������";
    public int beg_string_background=0xff0000;
    public int beg_string_textcolor=0x000000;
    public Font beg_string_font=Font.getFont(Font.FACE_MONOSPACE,Font.STYLE_PLAIN,Font.SIZE_SMALL);
    public int get_beg_string_width(){
        return beg_string_font.stringWidth(beg_string);
    }
    /*-----------------------------------------------------------*/

    /* ---------------��������� ������ -------------------------*/
    public int title_string_background1=0x000b6b;
    public int title_string_background2=0x474978;
    public int title_string_textcolor=0xffffff;
    public Font title_string_font=Font.getFont(Font.FACE_MONOSPACE,Font.STYLE_BOLD,Font.SIZE_SMALL);
    public int get_title_string_width(String s){
        return title_string_font.stringWidth(s);
    }
    /*-----------------------------------------------------------*/

    /*-----------------������----------------------------------*/
    public int button_border=0x000000;
    public int button_background=0xff0000;
    public int button_active_background=0x474978;
    public int button_textcolor=0x000000;
    public int active_button_textcolor=0x000000;
    public Font button_font=Font.getFont(Font.FACE_MONOSPACE,Font.STYLE_BOLD,Font.SIZE_SMALL);

    /*----------------------------------------------------------*/

    /*-----------------�������������� �����-----------------------*/
    public static String First_text ="��������� ������� - ���������� ���������� java-���������� "+
            "��� ������ ���������� ��������, ����������� ����� � ������ ��������:\n "+
            "-���������� � ����������� � ����� ������ ������������, ������� ��� �������;\n"+
            "-�������� � ���������;\n-���������� �������� ���������";
    public int First_text_textcolor=0x000000;
    public int First_text_FontSize=Font.SIZE_SMALL;
    public int First_text_FontStyle=Font.STYLE_PLAIN;
    public int First_text_FontType=Font.FACE_PROPORTIONAL;
    /*----------------------------------------------------------*/

    /*-------------------------main menu----------------------*/
    public int menu_item_background=0xffffff;
    public int menu_item_border=0xff0000;
    public int active_item_background=0x474978;
    public int menu_textcolor=0x474978;
    public int active_textcolor=0xffffff;
    public int menu_height=0;
    public Font menu_font=Font.getFont(Font.FACE_PROPORTIONAL,Font.STYLE_PLAIN,Font.SIZE_SMALL);
    public Font menu_font_big=Font.getFont(Font.FACE_PROPORTIONAL,Font.STYLE_BOLD,Font.SIZE_SMALL);

    /*---------------------------------------------------------*/


    /*--------------------�����-------------------------------*/
    public int scroll_color=0x999999;
    public int scroll_pols=0x000000;
    public int scroll_width=2;
    /*--------------------------------------------------------*/

    /*------------------���������-----------------------------*/
    public int combobox_focus=0xff0000;
    public int combobox_focuse_background=0xffffff;
    public int combobox_background=0xffffff;
    public int combobox_border=0x000000;
    public int combobox_sqcolor=0x999999;
    public int combobox_trcolor=0x000000;
    public int combobox_fontcolor=0x000000;
    public Font combobox_font=Font.getFont(Font.FACE_PROPORTIONAL,Font.STYLE_PLAIN,Font.SIZE_SMALL);
    public int combobox_list_border=0x000000;
    public int combobox_list_background=0xffffff;
    public int combobox_list_textcolor=0x000000;
    public int combobox_list_selected=0x474978;
    public int combobox_list_textselected=0x000000;
    public Font combobox_list_font=Font.getFont(Font.FACE_PROPORTIONAL,Font.STYLE_PLAIN,Font.SIZE_SMALL);
    /*----------------------------------------------------------*/

    /*----------------text color--------------------------------*/
    public int text_textcolor=0x000000;
    public int text_FontSize=Font.SIZE_SMALL;
    public int text_FontStyle=Font.STYLE_PLAIN;
    public int text_FontType=Font.FACE_PROPORTIONAL;
    public Font get_text_font(){
        return Font.getFont(CG.inst.text_FontType,CG.inst.text_FontStyle,CG.inst.text_FontSize);
    }
    /*---------------------------------------------------------*/

    public static void p_beg_string(Graphics g){
       g.setColor(CG.inst.beg_string_background);
       g.fillRect(0,0,CG.inst.width,CG.inst.beg_string_font.getHeight()+3);
       g.setColor(CG.inst.beg_string_textcolor);
       g.setFont(CG.inst.beg_string_font);
       g.drawString(CG.inst.beg_string, CG.inst.beg_string_x, 2, Graphics.LEFT | Graphics.TOP);
       g.drawString(CG.inst.beg_string, CG.inst.get_beg_string_width()+30+CG.inst.beg_string_x,
                                                            2, Graphics.LEFT | Graphics.TOP);
       g.drawString(CG.inst.beg_string, CG.inst.get_beg_string_width()*2+60+CG.inst.beg_string_x,
                                                            2, Graphics.LEFT | Graphics.TOP);
    }

    public static void p_title(Graphics g,String title,boolean strelki){
       int ht=CG.inst.title_string_font.getHeight()+3;
       int hb=CG.inst.beg_string_font.getHeight();
       CG.gradientBox(g,CG.inst.title_string_background1 ,CG.inst.title_string_background2 ,
               0,CG.inst.beg_string_font.getHeight()+3, CG.inst.width,ht, 0);
       if (strelki){
            g.setColor(CG.inst.background);

            //#if MIDP == "1.0"
            g.drawString("<", 5, hb+5, Graphics.LEFT | Graphics.TOP);
            g.drawString(">", CG.inst.width-ht+3, hb+5, Graphics.LEFT | Graphics.TOP);
            //#else
//#             g.fillTriangle(5,hb+3+ht/2,ht-3, hb+6, ht-3, hb+ht);
//#             g.fillTriangle(CG.inst.width-5,hb+3+ht/2,CG.inst.width-ht+3, hb+6, CG.inst.width-ht+3, hb+ht);
            //#endif

       }
       g.setColor(CG.inst.title_string_textcolor);
       g.setFont(CG.inst.title_string_font);
       int fw=CG.inst.menu_font.stringWidth(title);
       int x=5;
       if (CG.inst.width<fw){
            CG.inst.text_width=fw;
            x=CG.inst.text_x;
            g.drawString(title, x-5,hb+5, Graphics.LEFT | Graphics.TOP);
       }else g.drawString(title, CG.inst.width/2,hb+5, Graphics.HCENTER | Graphics.TOP);
    }

    public static void p_button(Graphics g,String[] leftbutton,String[] rightbutton,
                                    boolean show_leftbutton,boolean show_rightbutton,int active_button,
                                    String left_default,String right_default){
        g.setColor(CG.inst.button_background);
        g.fillRect(-1, CG.inst.height-CG.inst.button_font.getHeight()-3,(int)(CG.inst.width/2)+1,
                                                            CG.inst.button_font.getHeight()+3);
        g.setColor(CG.inst.button_border);
        g.drawRect(-1, CG.inst.height-CG.inst.button_font.getHeight()-3,(int)(CG.inst.width/2)+1,
                                                            CG.inst.button_font.getHeight()+3);
        g.setColor(CG.inst.button_background);
        g.fillRect((int)(CG.inst.width/2), CG.inst.height-CG.inst.button_font.getHeight()-3,
                                        (int)(CG.inst.width/2),CG.inst.button_font.getHeight()+3);
        g.setColor(CG.inst.button_border);
        g.drawRect((int)(CG.inst.width/2), CG.inst.height-CG.inst.button_font.getHeight()-3,
                                        (int)(CG.inst.width/2),CG.inst.button_font.getHeight()+3);
        g.setColor(CG.inst.button_textcolor);
        g.setFont(CG.inst.button_font);
        int gx=g.getClipX();
        int gy=g.getClipY();
        int gw=g.getClipWidth();
        int gh=g.getClipHeight();
        if (show_leftbutton){
            for(int i=0;i<leftbutton.length;i++){
                if (i==active_button) g.setColor(CG.inst.button_active_background);
                else g.setColor(CG.inst.button_background);
                g.fillRect(-1, CG.inst.height-(CG.inst.button_font.getHeight()+3)*(i+1),(int)(CG.inst.width/2)+1,
                                                            CG.inst.button_font.getHeight()+3);
                g.setColor(CG.inst.button_border);
                g.drawRect(-1, CG.inst.height-(CG.inst.button_font.getHeight()+3)*(i+1),(int)(CG.inst.width/2)+1,
                                                            CG.inst.button_font.getHeight()+3);
                if (i==active_button) g.setColor(CG.inst.active_button_textcolor);
                else g.setColor(CG.inst.button_textcolor);
                g.drawString(leftbutton[i], (int)(CG.inst.width/4),
                        CG.inst.height-(CG.inst.button_font.getHeight()+3)*(i+1)+2,
                        Graphics.HCENTER | Graphics.TOP);
            }
        }else {
            g.setClip(-1, CG.inst.height-CG.inst.button_font.getHeight()-3, (int)(CG.inst.width/2)+1,
                                                                CG.inst.button_font.getHeight()+3);
            g.drawString(left_default, (int)(CG.inst.width/4), CG.inst.height-CG.inst.button_font.getHeight()-1,
                                                                        Graphics.HCENTER | Graphics.TOP);
            g.setClip(gx, gy, gw, gh);
        }
        if (show_rightbutton){
            for(int i=0;i<rightbutton.length;i++){
                if (i==active_button) g.setColor(CG.inst.button_active_background);
                else g.setColor(CG.inst.button_background);
                g.fillRect((int)(CG.inst.width/2), CG.inst.height-(CG.inst.button_font.getHeight()+3)*(i+1),
                        (int)(CG.inst.width/2),CG.inst.button_font.getHeight()+3);
                g.setColor(CG.inst.button_border);
                g.drawRect((int)(CG.inst.width/2), CG.inst.height-(CG.inst.button_font.getHeight()+3)*(i+1),
                        (int)(CG.inst.width/2),CG.inst.button_font.getHeight()+3);
                if (i==active_button) g.setColor(CG.inst.active_button_textcolor);
                else g.setColor(CG.inst.button_textcolor);
                g.drawString(rightbutton[i], (int)(3*CG.inst.width/4),
                        CG.inst.height-(CG.inst.button_font.getHeight()+3)*(i+1)+2,
                        Graphics.HCENTER | Graphics.TOP);
            }
        } else {
            g.setClip((int)(CG.inst.width/2), CG.inst.height-CG.inst.button_font.getHeight()-3,
                                             (int)(CG.inst.width/2), CG.inst.button_font.getHeight()+3);
            g.drawString(right_default,3*CG.inst.width/4,CG.inst.height-CG.inst.button_font.getHeight()-1,
                                                                        Graphics.HCENTER | Graphics.TOP);
            g.setClip(gx, gy, gw, gh);
        }
    }

    public static void p_radiobutton(Graphics g,int x,int y,String text,boolean select,boolean active){
        g.setColor(CG.inst.text_textcolor);
        int r=CG.inst.menu_font.getHeight();
        g.drawArc(x+r/2, y,r,r,0,360);
        g.drawString(text, x+r+10, y, Graphics.LEFT | Graphics.TOP);
        if (select) g.fillArc(x+r/2+2, y+2,r-4,r-4,0,360);
        if (active) {
            g.setColor(CG.inst.combobox_focus);
            g.drawArc(x+r/2-1, y-1,r+2,r+2,0,360);
        }
    }

    public static void p_checkbox(Graphics g,int x,int y,String text,boolean select,boolean active){
        g.setColor(CG.inst.text_textcolor);
        int r=CG.inst.menu_font.getHeight();
        g.drawRect(x, y, r, r);
        g.drawString(text, x+r+10, y, Graphics.LEFT | Graphics.TOP);
        if (select) g.fillRect(x+2, y+2, r-3, r-3);
        if (active) {
            g.setColor(CG.inst.combobox_focus);
            g.drawRect(x-1, y-1, r+2, r+2);
        }
    }

    public static void p_comboboxe(Graphics g,String text,boolean focus,int x,int y,int w,int h,int y0,int height_full){
        int gx=g.getClipX();
        int gy=g.getClipY();
        int gw=g.getClipWidth();
        int gh=g.getClipHeight();
        /*if (y-h0+h>fullh) g.setClip(x-1, y-1, w+2, fullh-y-h0);*/
        if (focus) {
            g.setColor(CG.inst.combobox_focus);
            g.drawRect(x-1, y-1, w+2, h+2);
        }
        g.setColor(CG.inst.combobox_border);
        g.drawRect(x, y, w, h);
        if (focus)  g.setColor(CG.inst.combobox_focuse_background);
        else g.setColor(CG.inst.combobox_background);
        g.fillRect(x+1, y+1, w-1, h-1);
        g.setColor(CG.inst.combobox_border);
        g.drawRect(x+w-h, y, h, h);
        g.setColor(CG.inst.combobox_sqcolor);
        g.fillRect(x+w-h+1, y+1, h-1, h-1);
        g.setColor(CG.inst.combobox_trcolor);
        int hh=h/4;

        //#if MIDP == "1.0"
        g.drawLine(x+w-h+hh, y+hh,  x+w-h+3*hh, y+hh);
        g.drawLine(x+w-h+hh, y+hh, x+w-h+2*hh, y+3*hh);
        g.drawLine(x+w-h+3*hh, y+hh, x+w-h+2*hh, y+3*hh);
        //#else
//#         g.fillTriangle(x+w-h+hh, y+hh, x+w-h+3*hh, y+hh, x+w-h+2*hh, y+3*hh);
        //#endif

        g.setColor(CG.inst.combobox_fontcolor);
        g.setFont(CG.inst.combobox_font);
        if (y-y0+h>height_full) g.setClip(x+1, y+1, w-h-1, height_full-y-y0);
        if (y<=y0) g.setClip(x+1,y0, w-h-1,h-1);
        else g.setClip(x+1, y+1, w-h-1, h-1);
        g.drawString(text, x+5, y+3, Graphics.LEFT | Graphics.TOP);
        g.setClip(gx, gy, gw, gh);
    }

    static boolean combonapr=false;
    static int combox=0;
    static long combo_oldticker;
    static int comboscroll_active;

    public static void initcomboscrol(int a){
        if (comboscroll_active!=a){
            combo_oldticker=CG.inst.ticker_count;
            combonapr=false;
            combox=0;
            comboscroll_active=a;
        }
    }

    public static void p_opencombobox(Graphics g,int x,int y,int w,int h,Vector v,int list_active,int list_size){
        int y_add=0;
        int hpp;
        int gx=g.getClipX();
        int gy=g.getClipY();
        int gw=g.getClipWidth();
        int gh=g.getClipHeight();
        g.setColor(CG.inst.combobox_list_border);
        g.drawRect(x, y, w, h);
        g.setColor(CG.inst.combobox_list_background);
        g.setClip(x+1,y+1,w-1,h-1);
        g.fillRect(x+1,y+1,w-1,h-1);
        int hh=CG.inst.combobox_list_font.getHeight();
        g.setFont(CG.inst.combobox_list_font);
        if ((list_active+1)*hh>h) y_add=(list_active+1)*hh-h+1;
        int i=y_add/hh-1<0?0:y_add/hh-1;
        int e=(h+y_add)/hh+1>list_size?list_size:(h+y_add)/hh+1;
        for(;i<e;i++){
            if (i==list_active){
                g.setColor(CG.inst.combobox_list_selected);
                g.fillRect(x+1, y+2+i*hh-y_add,w-1, hh);
                g.setColor(CG.inst.combobox_list_textselected);
                int fw=CG.inst.menu_font.stringWidth((String)v.elementAt(i));
                initcomboscrol(i);
                if (w<fw){
                    combonapr=get_napr(combox,fw-w,combonapr);
                    combox=CG.inst.get_scrollx(combox,combonapr,combo_oldticker,CG.inst.text_scroll_speed);
                    g.drawString((String)v.elementAt(i),x+2+combox,y+2+i*hh-y_add, Graphics.LEFT | Graphics.TOP);
                    combo_oldticker=CG.inst.ticker_count;
                }else g.drawString((String)v.elementAt(i), x+2, y+2+i*hh-y_add,Graphics.LEFT | Graphics.TOP);
                //g.drawString((String)v.elementAt(i), x+2, y+2+i*hh-y_add,Graphics.LEFT | Graphics.TOP );
            }else {
                    g.setColor(CG.inst.combobox_list_textcolor);
                    g.drawString((String)v.elementAt(i), x+2, y+2+i*hh-y_add,Graphics.LEFT | Graphics.TOP );
            }
        }
        g.setColor(CG.inst.scroll_color);
        g.fillRect(x+CG.inst.width-20-CG.inst.scroll_width, y+1, CG.inst.scroll_width,h-1);
        g.setColor(CG.inst.scroll_pols);
        hpp=(int)(h/(list_size));if (hpp<2) hpp=3;
        g.fillRect(x+CG.inst.width-20-CG.inst.scroll_width, y+(int)(list_active*h/list_size), CG.inst.scroll_width, hpp);
        g.setClip(gx, gy, gw, gh);
    }

    public static void p_textfield(Graphics g,int x,int y,int w,int h,boolean active,String text){
        int gx=g.getClipX();
        int gy=g.getClipY();
        int gw=g.getClipWidth();
        int gh=g.getClipHeight();
        if (active) {
            g.setColor(CG.inst.combobox_focus);
            g.drawRect(x-1, y-1, w+2, h+2);
        }
        g.setColor(CG.inst.combobox_border);
        g.drawRect(x, y, w, h);
        g.setColor(CG.inst.combobox_background);
        g.fillRect(x+1, y+1, w-1, h-1);
        g.setColor(CG.inst.combobox_fontcolor);
        g.setFont(CG.inst.combobox_font);
        if (y<gy) g.setClip(x+1, gy, w-1, h-1);
        else g.setClip(x+1, y+1, w-1, h-1);
        g.drawString(text, x+5, y+3, Graphics.LEFT | Graphics.TOP);
        g.setClip(gx, gy, gw, gh);
   }

   public static void p_wait(Graphics g){
        g.setColor(CG.inst.text_textcolor);
        g.setFont(CG.inst.get_text_font());
        if (Parser.inst.process_data()){
            g.drawString("��������� ������ "+CG.inst.dots, 10, CG.inst.beg_string_font.getHeight()+
                CG.inst.title_string_font.getHeight()+10, Graphics.LEFT | Graphics.TOP);
        }
        else{
            g.drawString("�������� ������ "+CG.inst.dots, 10, CG.inst.beg_string_font.getHeight()+
                CG.inst.title_string_font.getHeight()+10, Graphics.LEFT | Graphics.TOP);
        }
   }

    public static void p_nodata(Graphics g){
        g.setColor(CG.inst.text_textcolor);
        g.setFont(CG.inst.get_text_font());
        g.drawString("������ ���", 10, CG.inst.beg_string_font.getHeight()+
                CG.inst.title_string_font.getHeight()+10, Graphics.LEFT | Graphics.TOP);
    }

    public static void p_progressbar(Graphics g,int x,int y,int w,int h,int text1,
                                                int textfull,String textunit,boolean text){
           g.setColor(CG.inst.combobox_list_background);
           g.fillRect(x, y, w, h);
           g.setColor(CG.inst.combobox_list_selected);
           g.fillRect(x, y, textfull==0?w:text1*w/textfull, h);
           g.setColor(CG.inst.text_textcolor);
           g.setFont(CG.inst.get_text_font());
           if (text) g.drawString(text1+"/"+textfull+textunit, CG.inst.width/2,y+2,Graphics.HCENTER | Graphics.TOP);
           g.setColor(CG.inst.combobox_border);
           g.drawRect(x, y, w, h);
    }


    /*  ------------Gradient darw start----------------------*/
    public static final int GRADIENT_VERTICAL = 0;
	public static final int GRADIENT_HORIZONTAL = 1;

	public static void gradientBox(Graphics g, int color1, int color2, int left,
                                   int top, int width, int height, int orientation){
		int max = orientation == GRADIENT_VERTICAL ? height : width;
		for(int i = 0; i < max; i++){
			int color = midColor(color1, color2, max * (max - 1 - i) / (max - 1), max);
			g.setColor(color);
			if(orientation == GRADIENT_VERTICAL) g.drawLine(left, top + i, left + width - 1, top + i);
			else g.drawLine(left + i, top, left + i, top + height - 1);
		}
	}

	static int midColor(int color1, int color2, int prop, int max){
		int red =
			(((color1 >> 16) & 0xff) * prop +
			((color2 >> 16) & 0xff) * (max - prop)) / max;
		int green =
			(((color1 >> 8) & 0xff) * prop +
			((color2 >> 8) & 0xff) * (max - prop)) / max;
		int blue =
			(((color1 >> 0) & 0xff) * prop +
			((color2 >> 0) & 0xff) * (max - prop)) / max;
		int color = red << 16 | green << 8 | blue;
		return color;
	}
    /*  ------------Gradient darw end----------------------*/

    public void set_shemafont(){
        if (Config.inst.shema.equals("�������")){
            background=0xffffff;
            beg_string_background=0xffffff;
            beg_string_textcolor=0x000000;
            title_string_background1=0x000b6b;
            title_string_background2=0x474978;
            title_string_textcolor=0xffffff;
            button_border=0x000000;
            button_background=0xffffff;
            button_active_background=0x474978;
            button_textcolor=0x000000;
            First_text_textcolor=0x000000;//�� ������ ��������
            menu_item_background=0xffffff;
            menu_item_border=0x474978;
            active_item_background=0x474978;
            menu_textcolor=0x474978;
            active_textcolor=0xffffff;
            combobox_focus=0x474978;
            combobox_focuse_background=0xffffff;
            combobox_background=0xffffff;
            combobox_border=0x000000;
            combobox_sqcolor=0x999999; //���� ��������
            combobox_trcolor=0x000000; //���� ������������
            combobox_fontcolor=0x000000;
            combobox_list_border=0x000000;
            combobox_list_background=0xffffff;
            combobox_list_textcolor=0x474978;
            combobox_list_selected=0x474978;
            combobox_list_textselected=0xffffff;
            text_textcolor=0x000000;  //����� �������� �����
            scroll_color=0x999999;
            scroll_pols=0x000000;
        }else if (Config.inst.shema.equals("�����")){
            background=0xa5a5a5;
            beg_string_background=0x696969;
            beg_string_textcolor=0x000000;
            title_string_background1=0x696969;
            title_string_background2=0xa5a5a5;
            title_string_textcolor=0xffffff;
            button_border=0x000000;
            button_background=0x696969;
            button_active_background=0xa5a5a5;
            button_textcolor=0x000000;
            First_text_textcolor=0x000000;//�� ������ ��������
            menu_item_background=0xa5a5a5;
            menu_item_border=0xa5a5a5;
            active_item_background=0x696969;
            menu_textcolor=0x000000;
            active_textcolor=0xffffff;
            combobox_focus=0xff0000;
            combobox_focuse_background=0xffffff;
            combobox_background=0xffffff;
            combobox_border=0x000000;
            combobox_sqcolor=0x999999; //���� ��������
            combobox_trcolor=0x000000; //���� ������������
            combobox_fontcolor=0x000000;
            combobox_list_border=0x000000;
            combobox_list_background=0xffffff;
            combobox_list_textcolor=0x000000;
            combobox_list_selected=0x696969;
            combobox_list_textselected=0xffffff;
            text_textcolor=0x000000;  //����� �������� �����
            scroll_color=0x999999;
            scroll_pols=0x000000;
        }else if (Config.inst.shema.equals("������")){
            background=0x000000;
            beg_string_background=0x000000;
            beg_string_textcolor=0xffffff;
            title_string_background1=0x000000;
            title_string_background2=0x999999;
            title_string_textcolor=0xffffff;
            button_border=0xffffff;
            button_background=0x999999;
            button_active_background=0xffffff;
            button_textcolor=0x000000;
            First_text_textcolor=0xffffff;//�� ������ ��������
            menu_item_background=0x000000;
            menu_item_border=0x000000;
            active_item_background=0xffffff;
            menu_textcolor=0xffffff;
            active_textcolor=0x000000;
            combobox_focus=0xffffff;
            combobox_focuse_background=0xffffff;
            combobox_background=0xffffff;
            combobox_border=0x000000;
            combobox_sqcolor=0x999999; //���� ��������
            combobox_trcolor=0x000000; //���� ������������
            combobox_fontcolor=0x000000;
            combobox_list_border=0x000000;
            combobox_list_background=0xffffff;
            combobox_list_textcolor=0x000000;
            combobox_list_selected=0x000000;
            combobox_list_textselected=0xffffff;
            text_textcolor=0xffffff;  //����� �������� �����
            scroll_color=0x999999;
            scroll_pols=0xffffff;
        }else if (Config.inst.shema.equals("�������")){
            background=0x7ba37b;
            beg_string_background=0x7ba37b;
            beg_string_textcolor=0x000000;
            title_string_background1=0x7ba37b;
            title_string_background2=0xd1f7d1;
            title_string_textcolor=0x000000;
            button_border=0x7ba37b;
            button_background=0xd1f7d1;
            button_active_background=0x7ba37b;
            button_textcolor=0x000000;
            First_text_textcolor=0x000000;//�� ������ ��������
            menu_item_background=0x7ba37b;
            menu_item_border=0x288f28;
            active_item_background=0x288f28;
            menu_textcolor=0x000000;
            active_textcolor=0xffffff;
            combobox_focus=0xff0000;
            combobox_focuse_background=0xffffff;
            combobox_background=0xffffff;
            combobox_border=0x000000;
            combobox_sqcolor=0x999999; //���� ��������
            combobox_trcolor=0x000000; //���� ������������
            combobox_fontcolor=0x000000;
            combobox_list_border=0x000000;
            combobox_list_background=0xffffff;
            combobox_list_textcolor=0x000000;
            combobox_list_selected=0x288f28;
            combobox_list_textselected=0xffffff;
            text_textcolor=0x000000;  //����� �������� �����
            scroll_color=0x999999;
            scroll_pols=0x000000;
        }else if (Config.inst.shema.equals("�������")){
            background=0xffffff;
            beg_string_background=0xff0000;
            beg_string_textcolor=0x000000;
            title_string_background1=0x000b6b;
            title_string_background2=0xaf2424;
            title_string_textcolor=0xffffff;
            button_border=0x000000;
            button_background=0xff0000;
            button_active_background=0xaf2424;
            button_textcolor=0x000000;
            First_text_textcolor=0x000000;//�� ������ ��������
            menu_item_background=0xffffff;
            menu_item_border=0xff0000;
            active_item_background=0xaf2424;
            menu_textcolor=0xaf2424;
            active_textcolor=0xffffff;
            combobox_focus=0xff0000;
            combobox_focuse_background=0xffffff;
            combobox_background=0xffffff;
            combobox_border=0x000000;
            combobox_sqcolor=0x999999; //���� ��������
            combobox_trcolor=0x000000; //���� ������������
            combobox_fontcolor=0x000000;
            combobox_list_border=0x000000;
            combobox_list_background=0xffffff;
            combobox_list_textcolor=0x000000;
            combobox_list_selected=0xaf2424;
            combobox_list_textselected=0x000000;
            text_textcolor=0x000000;  //����� �������� �����
            scroll_color=0x999999;
            scroll_pols=0x000000;
        }

        int fontsize=Font.SIZE_SMALL;
        if (Config.inst.font.equals("������")){
            fontsize=Font.SIZE_SMALL;
        }else if (Config.inst.font.equals("�������")){
            fontsize=Font.SIZE_MEDIUM;
        }else if (Config.inst.font.equals("�������")){
            fontsize=Font.SIZE_LARGE;
        }

        beg_string_font=Font.getFont(Font.FACE_MONOSPACE,Font.STYLE_PLAIN,fontsize);
        title_string_font=Font.getFont(Font.FACE_MONOSPACE,Font.STYLE_BOLD,fontsize);
        button_font=Font.getFont(Font.FACE_MONOSPACE,Font.STYLE_BOLD,fontsize);
        First_text_FontSize=fontsize;
        menu_font=Font.getFont(Font.FACE_PROPORTIONAL,Font.STYLE_PLAIN,fontsize);
        menu_font_big=Font.getFont(Font.FACE_PROPORTIONAL,Font.STYLE_BOLD,fontsize);
        combobox_font=Font.getFont(Font.FACE_PROPORTIONAL,Font.STYLE_PLAIN,fontsize);
        combobox_list_font=Font.getFont(Font.FACE_PROPORTIONAL,Font.STYLE_PLAIN,fontsize);

        fontsize=Font.SIZE_SMALL;
        if (Config.inst.font_text.equals("������")){
            fontsize=Font.SIZE_SMALL;
        }else if (Config.inst.font_text.equals("�������")){
            fontsize=Font.SIZE_MEDIUM;
        }else if (Config.inst.font_text.equals("�������")){
            fontsize=Font.SIZE_LARGE;
        }
        text_FontSize=fontsize;
    }


    public static String replace_str(String s,String s1,String s2){
        int s1l=s1.length();
        int i=s.indexOf(s1);
        while(i!=-1){
            s=s.substring(0,i-1)+s2+s.substring(i+s1l);
            i=s.indexOf(s1);
        }
        return s;
    }
}
