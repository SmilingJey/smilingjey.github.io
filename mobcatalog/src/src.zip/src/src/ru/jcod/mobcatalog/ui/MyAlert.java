package ru.jcod.mobcatalog.ui;

import ru.jcod.mobcatalog.*;
import javax.microedition.lcdui.Alert;
import javax.microedition.lcdui.AlertType;
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.CommandListener;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Displayable;

public class MyAlert extends Alert implements CommandListener{

    Command cback;
    Command cOk;
    String text;

    public MyAlert(String text) {
        super("������",text, null, AlertType.ERROR);
        try {
           jbInit();
        }
        catch(Exception e) {
            e.printStackTrace();
        }
    }

    private void jbInit() throws Exception {
        setCommandListener(this);
        cback=new Command("�����", Command.CANCEL, 1);
        cOk=new Command("��.����", Command.OK, 1);
        addCommand(cback);
        addCommand(cOk);
        setTimeout(FOREVER);
        setCommandListener(this);
    }

    public void commandAction(Command c, Displayable d) {
        if (c.equals(cOk)) ScreenCanvas.inst.set_current_canvas(SMain.inst);
        MobileCatalog.inst.set_screancanvas();
    }

}