package ru.jcod.mobcatalog.data;

import java.util.Vector;

public class MyTable {

    public int table_prop1=0;
    /*public int table_prop2=0;
    public String table_prop_string1="";
    public String table_prop_string2="";*/

    public Vector col1;
    public Vector col2;
    public Vector col3;

    public MyTable(){
        col1=new Vector(1);  //id
        col2=new Vector(1);  //������������
        col3=new Vector(1);  //������ �� �������
    }

    public void clear(){
        col1.removeAllElements();
        col2.removeAllElements();
        col3.removeAllElements();
    }

    public void add(Object data1,Object data2,Object data3){
        col1.addElement(data1);
        col2.addElement(data2);
        col3.addElement(data3);
    }

    public void del(int i){
        col1.removeElementAt(i);
        col2.removeElementAt(i);
        col3.removeElementAt(i);
    }

    public void set_col1(Object data,int index){
        col1.setElementAt(data, index);
    }

    public void set_col2(Object data,int index){
        col2.setElementAt(data, index);
    }

    public void set_col3(Object data,int index){
        col3.setElementAt(data, index);
    }

    public int get_col1(int i){
        return Integer.parseInt((String)col1.elementAt(i));
    }

    public String get_col2(int i){
        return (String)col2.elementAt(i);
    }

    public MyTable get_col3(int i){
        return (MyTable)col3.elementAt(i);
    }

    public String get_col3_s(int i){
        return (String)col3.elementAt(i);
    }

    public int where_data(Object id){
        int i=col1.indexOf(id);
        if (i!=-1){
            if (col3.elementAt(i)!=null) return i;
            else return -1;
        }else return i;
    }

    public boolean empty(){
        return col1.isEmpty();
    }

    public int size(){
        return col1.size();
    }

    /*public void print(){
        for(int i=0;i<size();i++){
            //System.out.println(get_col1(i)+"\t"+get_col2(i)+"\t"+get_col3_s(i));
        }
    }*/
}
