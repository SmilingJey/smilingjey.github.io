package ru.jcod.mobcatalog.ui;

import ru.jcod.mobcatalog.data.MyTable;
import ru.jcod.mobcatalog.data.MyData;
import ru.jcod.mobcatalog.data.MyLocate;
import java.util.Vector;
import javax.microedition.lcdui.Graphics;

public class SObiav implements ICanvas{

    public static SObiav inst;
    String title="����������";
    String filtr_text="";
    String text;
    String leftbutton[]={"������","��.����","��������","���.�����."};
    String rightbutton[]={"��.����"};
    boolean show_leftbutton=false;
    boolean show_rightbutton=false;
    int active_button=0;
    int radiobutton_select=0;
    int active_item=0;
    int y_scroll=0;
    int combobox_list_active=0;
    public Vector combobox_list;
    boolean loadrazdel=false;
    boolean loadsubrazdel=false;
    boolean norazdel=false;
    boolean nosubrazdel=false;
    boolean allcity=false;
    boolean combobox_list_show=false;
    int list_size,list_active=0;
    MyTable comboboxlist;
    int hpp,h00,combobox_height,y0,height_full,text_height,line1,line2;
    int line3,combo1,combo2,textfield,checkbox,h,y;
    String razdel_text="";
    String subrazdel_text="";

    boolean menu_scroll;

    public SObiav(){
        inst = this;
    }

    public void paint(Graphics g) {
       CG.p_beg_string(g);
       CG.p_title(g,title,false);
       razdel_text="";
       subrazdel_text="";
       if (menu_scroll){
            if (active_item==1 && height_full<combo2+combobox_height) y_scroll=combo2+combobox_height-height_full;
            else if (active_item==2 && height_full<textfield+combobox_height) y_scroll=textfield+combobox_height-height_full;
            else if (active_item==3 && height_full<checkbox) y_scroll=checkbox-height_full;
       }

       g.setFont(CG.inst.get_text_font());
       g.setColor(CG.inst.text_textcolor);
       g.setClip(0, y0, CG.inst.width, height_full);

       g.drawString("�����: "+MyLocate.inst.get_city_name(),CG.inst.width/2,y0+4-y_scroll, Graphics.HCENTER | Graphics.TOP);
       g.drawString("������",CG.inst.width/2,line1-y_scroll, Graphics.HCENTER | Graphics.TOP);
       g.drawString("���������",CG.inst.width/2,line2-y_scroll, Graphics.HCENTER | Graphics.TOP);
       g.drawString("������",CG.inst.width/2,line3-y_scroll, Graphics.HCENTER | Graphics.TOP);
      
       razdel_text="";
       if (norazdel) razdel_text="��� ��������";
       else if (loadrazdel) razdel_text="�������� ������";
       else if (MyData.inst.sec_selected_id==-1)  razdel_text="�������� ������";
       else  razdel_text=MyData.inst.table_sec.get_col2(MyData.inst.sec_selected_id);
       CG.p_comboboxe(g,razdel_text,active_item==0,10,combo1-y_scroll, CG.inst.width-20,combobox_height,y0,height_full);

       subrazdel_text="";
       if (nosubrazdel) subrazdel_text="��� �����������";
       else if (loadsubrazdel) subrazdel_text="�������� ������";
       else if (MyData.inst.subsec_selected_id==-1)  subrazdel_text="�������� ���������";
       else  subrazdel_text=MyData.inst.get_table_subsec().get_col2(MyData.inst.subsec_selected_id);
       CG.p_comboboxe(g,subrazdel_text,active_item==1,10,combo2-y_scroll, CG.inst.width-20,combobox_height,y0,height_full);
       if (filtr_text.equals("")) text="������� ��������";else text=filtr_text;
       CG.p_textfield(g,10,textfield-y_scroll,CG.inst.width-20,combobox_height,active_item==2,text);
       CG.p_checkbox(g,10, checkbox-y_scroll, "����� �� ����� ������", allcity, active_item==3);

       if (menu_scroll){
           g.setColor(CG.inst.scroll_color);
           g.fillRect(CG.inst.width-CG.inst.scroll_width, y0, CG.inst.scroll_width,height_full);
           g.setColor(CG.inst.scroll_pols);
           hpp=(int)(height_full/4);
           h00=(int)(active_item*hpp);
           g.fillRect(CG.inst.width-CG.inst.scroll_width, y0+h00, CG.inst.scroll_width, hpp);
       }
       g.setClip(0, 0, CG.inst.width, CG.inst.height);
       CG.p_button(g, leftbutton, null, show_leftbutton, false, active_button, "�������", "������");
       if (combobox_list_show){
           if (active_item==0){
               y=combo1-y_scroll+combobox_height;
               h=CG.inst.height-y-10;
           }else if (active_item==1){
                if (combo2-y_scroll<2*height_full/3){y=combo2+combobox_height-y_scroll;h=CG.inst.height-y-10;}
                else {y=y0+5;h=combo2-y_scroll-y;}
           }
           CG.p_opencombobox(g, 10, y,CG.inst.width-20, h, combobox_list, list_active, list_size);
       }
    }

    public void keyPressed( int key){
        if (key == 1){
            if (show_leftbutton || show_rightbutton){
                if (active_button!=(show_leftbutton?leftbutton.length-1:rightbutton.length-1)) active_button++;
                else active_button=0;
            }else{
               if (!combobox_list_show){
                    if (!(loadrazdel || loadsubrazdel)){
                        if (active_item!=0) active_item--;
                        else active_item=3;
                    }
               }else{
                    if (list_active!=0) list_active--;
                    else list_active=list_size-1;
               }
            }
       }else if (key == 6){
            if (show_leftbutton || show_rightbutton){
                if (active_button!=0) active_button--;
                else active_button=show_leftbutton?leftbutton.length-1:rightbutton.length-1;
            }else{
                if (!combobox_list_show){
                    if (!(loadrazdel || loadsubrazdel)){
                        if (active_item!=3) active_item++;
                        else active_item=0;
                    }
                }else{
                    if (list_active!=list_size-1) list_active++;
                    else list_active=0;
                }
            }
       }else if (key == -6){
           if (leftbutton.length>1){
               show_leftbutton=!show_leftbutton;
               active_button=0;
           }else{
               //MidletProject.quitApp();
           }
       }else if (key == -7){
           if (rightbutton.length>1){
               show_rightbutton=!show_rightbutton;
               active_button=0;
           }else{
               int secid=MyData.inst.get_sec();
               if (secid!=-1){
                    SObiav_list.inst.load_data=true;
                    SObiav_list.inst.search=false;
                    MyData.inst.load_table_ann(1,Integer.parseInt(MyLocate.inst.get_city()), secid, filtr_text);
                    ScreenCanvas.inst.set_current_canvas(SObiav_list.inst);
               }else{
                   active_item=0;
               }
           }
       }else if (key == 2){

       }else if (key == 5){

       }else if (key == -8){
           if(show_leftbutton){
               if (active_button==1){
                    ScreenCanvas.inst.set_current_canvas(SMain.inst);
               }else if (active_button==2){
                   ScreenCanvas.inst.set_current_canvas(SLocate.inst);
               }else if (active_button==3){
                   SObiav_add.inst.clear();
                   ScreenCanvas.inst.set_current_canvas(SObiav_add.inst);
               }
               show_leftbutton=false;
               active_button=0;
           }else if(show_rightbutton){
               if (active_button==0){

               }
               show_rightbutton=false;
               active_button=0;
           } else{
               if (combobox_list_show){
                    if (active_item==0){
                        if (MyData.inst.sec_selected_id!=list_active-1){
                            if (list_active==0) MyData.inst.sec_selected_id=-1;
                            else MyData.inst.sec_selected_id=list_active-1;
                            MyData.inst.subsec_selected_id=-1;
                        }
                        combobox_list_show=false;
                    }if (active_item==1){
                        if (list_active==0) MyData.inst.subsec_selected_id=-1;
                        else MyData.inst.subsec_selected_id=list_active-1;
                        combobox_list_show=false;
                    }
               }else{
                    if (active_item==0 && !(loadrazdel || loadsubrazdel)){
                        loadrazdel=true;
                        MyData.inst.load_table_sec();
                    }else if (active_item==1 && !(loadrazdel || loadsubrazdel)){
                        if (MyData.inst.sec_selected_id==-1 ){
                            active_item=0;
                        }else{
                            loadsubrazdel=true;
                            MyData.inst.load_table_sucsec(MyData.inst.table_sec.get_col1(MyData.inst.sec_selected_id));
                        }
                    }else if (active_item==2){
                        Search_inputbox.inst.show(this,"������� ����� �������",null);
                    }else if (active_item==3){
                        allcity=!allcity;
                    }
               }

           }
       }
    }

    public void loadlist(MyTable list){
        int c=list.size();
        if (c>0){
            comboboxlist=new MyTable();
            comboboxlist.add("-1", "�� �������", null);
            for(int i=0;i<c;i++) comboboxlist.add(list.col1.elementAt(i),list.col2.elementAt(i), null);
        }else comboboxlist=list;

        if (active_item==0) {
            loadrazdel=false;
            norazdel=false;
            if (comboboxlist.empty()){
                MyData.inst.sec_selected_id=-1;
                norazdel=true;
            }
        }else if (active_item==1) {
            loadsubrazdel=false;
            nosubrazdel=false;
            if (comboboxlist.empty()){
                MyData.inst.subsec_selected_id=-1;
                nosubrazdel=true;
            }
        }
        combobox_list=comboboxlist.col2;
        list_active=0;
        list_size=combobox_list.size();
        if (!combobox_list.isEmpty()) {
            CG.initcomboscrol(-1);
            combobox_list_show=true;
        }
    }

    public void setActive(){
       
       combobox_height=CG.inst.combobox_font.getHeight()+4;
       y0=CG.inst.beg_string_font.getHeight()+ CG.inst.title_string_font.getHeight()+6;
       height_full=CG.inst.height-y0-CG.inst.button_font.getHeight()-3;
       text_height=CG.inst.get_text_font().getHeight()+3;
       line1=y0+text_height+4;
       line2=y0+text_height*2+combobox_height+8;
       line3=y0+text_height*3+combobox_height*2+12;
       combo1=y0+text_height*2+4;
       combo2=y0+text_height*3+combobox_height+8;
       textfield=y0+text_height*4+combobox_height*2+12;
       checkbox=y0+text_height*4+combobox_height*3+20;
       menu_scroll=y0+text_height*4+combobox_height*4+20>height_full;
       y_scroll=0;
    }
}
