package ru.jcod.mobcatalog.ui;

import javax.microedition.lcdui.Graphics;

public interface ICanvas {
    public void paint(Graphics g);
    public void keyPressed(int key);
    public void setActive();
}
