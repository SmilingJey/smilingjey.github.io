package ru.jcod.mobcatalog.ui;

import ru.jcod.mobcatalog.data.MyTable;
import ru.jcod.mobcatalog.data.MyData;
import ru.jcod.mobcatalog.data.MyLocate;
import javax.microedition.lcdui.Graphics;

public class SSubCat implements ICanvas{

    public static SSubCat inst;
    private String title="������������";
    private String leftbutton[]={"�����"};
    private String rightbutton[]={"�������"};
    private boolean show_leftbutton=false;
    private boolean show_rightbutton=false;
    private int active_button=0;
    private int active_menu_item=0;
    private int h0,hh,fullh,menu_width,yadd,i,e,fw,x,hpp;
    private boolean menu_scroll;

    public MyTable table=null;
    public boolean load_data=false;

    public SSubCat(){
        inst = this;
    }

    public void paint(Graphics g) {
       CG.p_beg_string(g);
       CG.p_title(g,title,false);
       if (load_data) CG.p_wait(g);
       else if (table==null) CG.p_nodata(g);
       else if (table.size()<=0) CG.p_nodata(g);
       else p_menu(g);
       CG.p_button(g, leftbutton, rightbutton, false, show_rightbutton, active_button, "�����", "�������");
    }

    public void p_menu(Graphics g){
        g.setClip(0, h0, CG.inst.width, fullh);
        yadd=0;
        if ((active_menu_item+1)*hh>fullh) yadd=(active_menu_item+1)*hh-fullh+1;
        i=yadd/hh-1<0?0:yadd/hh-1;
        e=(fullh+yadd)/hh+1>table.size()?table.size():(fullh+yadd)/hh+1;
        for(;i<e;i++){
            if (i==active_menu_item) g.setColor(CG.inst.active_item_background);
            else g.setColor(CG.inst.menu_item_background);
            g.fillRect(0, h0+i*hh-yadd, menu_width,hh);
            g.setFont(CG.inst.menu_font);
            if (i==active_menu_item) g.setColor(CG.inst.active_textcolor);
            else g.setColor(CG.inst.menu_textcolor);
            fw=CG.inst.menu_font.stringWidth(table.get_col2(i));
            x=5;
            if (CG.inst.width<fw){
                if (i==active_menu_item){
                    CG.inst.text_width=fw;
                    x=CG.inst.text_x;
                }
                g.drawString(table.get_col2(i), x,h0+i*hh+2-yadd, Graphics.LEFT | Graphics.TOP);
            }else
                g.drawString(table.get_col2(i), (int)(CG.inst.width/2),h0+i*hh+2-yadd, Graphics.HCENTER | Graphics.TOP);
            g.setColor(CG.inst.menu_item_border);
            g.drawRect(0, h0+i*hh-yadd, menu_width-1,hh);
        }

       if (menu_scroll){
           g.setColor(CG.inst.scroll_color);
           g.fillRect(CG.inst.width-CG.inst.scroll_width, h0, CG.inst.scroll_width,fullh);
           g.setColor(CG.inst.scroll_pols);
           hpp=(int)(fullh/(table.size()));if (hpp<2) hpp=3;
           g.fillRect(CG.inst.width-CG.inst.scroll_width, h0+(int)(active_menu_item*fullh/table.size()), CG.inst.scroll_width, hpp);
       }
       g.setClip(0, 0, CG.inst.width, CG.inst.height);
    }


    public void keyPressed(int key){
       if (key == 1) {
            if (show_leftbutton || show_rightbutton){
                if (active_button!=(show_leftbutton?leftbutton.length-1:rightbutton.length-1)) active_button++;
                else active_button=0;
            }else{
                if (!load_data && table!=null && !table.empty()){
                    if (active_menu_item!=0) active_menu_item--;
                    else active_menu_item=table.size()-1;
                }
            }
       }else if (key == 6){
            if (show_leftbutton || show_rightbutton){
                if (active_button!=0) active_button--;
                else active_button=show_leftbutton?leftbutton.length-1:rightbutton.length-1;
            }else{
                if (!load_data && table!=null && !table.empty()){
                    if (active_menu_item!=table.size()-1) active_menu_item++;
                    else active_menu_item=0;
                }
            }
       }else if (key == -6){
            ScreenCanvas.inst.set_current_canvas(SCat.inst);
       }else if (key == -8 || key == -7){
           if(show_leftbutton){
               ScreenCanvas.inst.set_current_canvas(SCat.inst);
               show_leftbutton=false;
               active_button=0;
           }else if(show_rightbutton){
               if (active_button==1){
                   ScreenCanvas.inst.set_current_canvas(SMain.inst);
               }else if (active_button==2){
                   ScreenCanvas.inst.set_current_canvas(SLocate.inst);
               }
               show_rightbutton=false;
               active_button=0;
           } else{
               if (!load_data && table!=null && !table.empty()){
                    SNames.inst.load_data=true;
                    SNames.inst.search=false;
                    MyData.inst.load_names(table.get_col1(active_menu_item),
                                         Integer.parseInt(MyLocate.inst.get_city()),1);
                    ScreenCanvas.inst.set_current_canvas(SNames.inst);
               }
           }
       }
       CG.inst.text_x=5;
    }

    public void load_data(MyTable table){
        active_menu_item=0;
        this.table=table;
        menu_scroll=(hh*table.size()>fullh);
        if (menu_scroll) menu_width=CG.inst.width-CG.inst.scroll_width;
        load_data=false;
        ScreenCanvas.inst.repaint();
    }

    public void setActive(){
        h0=CG.inst.beg_string_font.getHeight()+ CG.inst.title_string_font.getHeight()+6;
        hh=(CG.inst.menu_height==0)?CG.inst.menu_font.getHeight()+3:CG.inst.menu_height;
        fullh=CG.inst.height-h0-CG.inst.button_font.getHeight()-3;
        menu_width=CG.inst.width;
    }
}
