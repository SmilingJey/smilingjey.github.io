package ru.jcod.mobcatalog.ui;

import ru.jcod.mobcatalog.data.MyLocate;
import ru.jcod.mobcatalog.*;
import java.util.Vector;
import javax.microedition.lcdui.Graphics;
import ru.jcod.mobcatalog.net.Parser;

public class SLocate implements ICanvas{

    public static SLocate inst;
    String title="��������������";
    public Vector combobox_list;
    boolean loadrg=false,loadray=false,loadpunkt=false,loadstreet=false;
    boolean norg=false,noray=false,nopunkt=false,nostreet=false,combobox_list_show=false;
    int hhc,th,x,yy,y,w,h,h0,fullh,combobox_list_size,y_scroll,active_item,combobox_list_active=0;

    public SLocate(){
        inst = this;
    }

    public void paint(Graphics g) {
       CG.p_beg_string(g);
       CG.p_title(g,title,false);
       p_comboboxes(g);
       CG.p_button(g, null, null, false, false, 0, "��.����", "���������");
       if (combobox_list_show){
           yy=h0;y=0;h=0;
           if (active_item==0) {
               y=h0+hhc+th+10;
               h=CG.inst.height-y-10;
           }else if (active_item==1) {
                yy=hhc*2+th*2+25-y_scroll;
                if (yy<2*fullh/3){y=h0+hhc*2+th*2+20;h=CG.inst.height-y-10;}
                else {y=h0+5;h=hhc+th*2+15;}

           }else if (active_item==2) {
                yy=hhc*3+th*3+30-y_scroll;
                if (yy<2*fullh/3){y=h0+hhc*3+th*3+30;h=CG.inst.height-y-10;}
                else {y=h0+5;h=hhc*2+th*3+25;}

           }else if (active_item==3) {
                yy=hhc*4+th*4+40-y_scroll;
                if (yy<2*fullh/3){y=h0+hhc*4+th*4+40;h=CG.inst.height-y-10;}
                else {y=h0+5;h=hhc*3+th*4+35-y_scroll;}
           }
           CG.p_opencombobox(g,10,y,CG.inst.width-20,h,combobox_list,combobox_list_active,combobox_list_size);
       }
    }

    public void p_comboboxes(Graphics g){
        hhc=CG.inst.combobox_font.getHeight()+4;
        th=CG.inst.get_text_font().getHeight();
        h0=CG.inst.beg_string_font.getHeight()+ CG.inst.title_string_font.getHeight()+6;
        fullh=CG.inst.height-h0-CG.inst.button_font.getHeight()-3;
        boolean menu_scroll=(hhc*4+th*5+45>fullh);
        y_scroll=0;
        if (menu_scroll){
            if (active_item==1 && fullh<hhc*2+th*2+25) y_scroll=hhc*2+th*2+25-fullh;
            if (active_item==2 && fullh<hhc*3+th*3+35) y_scroll=hhc*3+th*3+35-fullh;
            if (active_item==3 && fullh<hhc*4+th*5+50) y_scroll=hhc*4+th*5+50-fullh;
        }
        g.setColor(CG.inst.text_textcolor);
        g.setFont(CG.inst.get_text_font());
        g.setClip(0, h0, CG.inst.width, fullh);
        g.drawString("������",CG.inst.width/2, h0+5-y_scroll, Graphics.HCENTER | Graphics.TOP);
        g.drawString("�����, �����", CG.inst.width/2, h0+hhc+th+15-y_scroll, Graphics.HCENTER | Graphics.TOP);
        g.drawString("��������� �����", CG.inst.width/2, h0+hhc*2+th*2+25-y_scroll, Graphics.HCENTER | Graphics.TOP);
        //g.drawString("�����", CG.inst.width/2, h0+hhc*3+th*3+35-y_scroll, Graphics.HCENTER | Graphics.TOP);
        //g.drawString("����� ����� �����", CG.inst.width/2, h0+hhc*4+th*4+45-y_scroll, Graphics.HCENTER | Graphics.TOP);

        String region_text="";
        if (norg) region_text="��� ��������";
        else if (loadrg){
            region_text="�������� ������";
            if (Parser.inst.process_data()) region_text="��������� ������";
        } else if (MyLocate.inst.rg_id.equals("-1"))  region_text="�������� ������";
        else  region_text=MyLocate.inst.rg_name;
        CG.p_comboboxe(g,region_text,active_item==0,10,h0+th+10-y_scroll, CG.inst.width-20,hhc,h0,fullh);
        
        String rayon_text="";
        if (noray) rayon_text="��� �������";
        else if (loadray){
            rayon_text="�������� ������";
            if (Parser.inst.process_data()) rayon_text="��������� ������";
        }else if (MyLocate.inst.ray_id.equals("-1"))  rayon_text="�������� �����";
        else rayon_text=MyLocate.inst.ray_name;
        CG.p_comboboxe(g,rayon_text,active_item==1,10,h0+hhc+th*2+20-y_scroll, CG.inst.width-20,hhc,h0,fullh);

        String punkt_text="";
        if (nopunkt) punkt_text="��� ���.�������";
        else if (loadpunkt) {
            punkt_text="�������� ������";
            if (Parser.inst.process_data()) punkt_text="��������� ������";
        } else if (MyLocate.inst.punkt_id.equals("-1")) punkt_text="�������� ���. �����";
        else punkt_text=MyLocate.inst.punkt_name;
        CG.p_comboboxe(g,punkt_text,active_item==2,10,h0+hhc*2+th*3+30-y_scroll, CG.inst.width-20,hhc,h0,fullh);

        /*String street_text="";
        if (nostreet) street_text="��� ����";
        else if (loadstreet){
            street_text="�������� ������";
            if (Net_connect.inst.r!=null)
                if (Net_connect.inst.r.process_data) street_text="��������� ������";
        }else if (MyLocate.inst.street_id.equals("-1"))  street_text="�������� �����";
        else street_text=MyLocate.inst.street_name;
        CG.p_comboboxe(g,street_text,active_item==3,10,h0+hhc*3+th*4+40-y_scroll, CG.inst.width-20,hhc,h0,fullh);*/

        if (menu_scroll){
           g.setColor(CG.inst.scroll_color);
           g.fillRect(CG.inst.width-CG.inst.scroll_width, h0, CG.inst.scroll_width,fullh);
           g.setColor(CG.inst.scroll_pols);
           int hpp=(int)(fullh/3);
           int h00=(int)(active_item*hpp);
           g.fillRect(CG.inst.width-CG.inst.scroll_width, h0+h00, CG.inst.scroll_width, hpp);
        }
        g.setClip(0, 0, CG.inst.width, CG.inst.height);
    }

    public void keyPressed( int key){
       if (key == 1){
           if (!combobox_list_show){
               if (!(loadrg || loadray || loadpunkt || loadstreet)){
                    if (active_item!=0) active_item--;
                    else active_item=2;
               }
           }else{
                if (combobox_list_active!=0) combobox_list_active--;
                else combobox_list_active=combobox_list_size-1;
           }
       }else if (key == 6){
           if (!combobox_list_show){
               if (!(loadrg || loadray || loadpunkt || loadstreet)){
                if (active_item!=2) active_item++;
                else active_item=0;
               }
           }else{     
                if (combobox_list_active!=combobox_list_size-1) combobox_list_active++;
                else combobox_list_active=0;
           }
       }else if (key == -6){
           ScreenCanvas.inst.set_current_canvas(SMain.inst);
       }else if (key == -7){
           Config.inst.saveconf();
           ScreenCanvas.inst.set_current_canvas(SMain.inst);
       }else if (key == 2){

       }else if (key == 5){

       }else if (key == -8){
            if (!combobox_list_show){
                if (active_item==0 && !loadrg) {
                    loadrg=true;
                    MyLocate.inst.load_rg();
                }else if (active_item==1) {
                    if (MyLocate.inst.rg_id.equals("-1")) active_item=0;
                    else {
                        if (MyLocate.inst.ray_id.equals("-1") || MyLocate.inst.get_v_ray_name()==null){
                            if (!loadray){
                                loadray=true;
                                MyLocate.inst.load_ray();
                            }
                        }else{
                            loadlist(MyLocate.inst.get_v_ray_name());
                        }
                    }
                }
                else if (active_item==2) {
                    if (MyLocate.inst.ray_id.equals("-1")) active_item=1;
                    else {
                        if (MyLocate.inst.punkt_id.equals("-1") || MyLocate.inst.get_v_punkt_name()==null){
                            if (!loadpunkt){
                                loadpunkt=true;
                                MyLocate.inst.load_punkt();
                            }
                        }else{
                            loadlist(MyLocate.inst.get_v_punkt_name());
                        }
                    }
                }
                else if (active_item==3) {
                    if (MyLocate.inst.get_city().equals("-1")) active_item=2;
                    else {
                        if (MyLocate.inst.street_id.equals("-1") || MyLocate.inst.get_v_street_name()==null){
                            if (!loadstreet){
                                loadstreet=true;
                                MyLocate.inst.load_street();
                            }
                        }else{
                            loadlist(MyLocate.inst.get_v_street_name());
                        }
                    }
                }
            } else{
                set_loc();
                combobox_list_active=0;
                combobox_list_show=false;
            }
       }
    }

    public void set_loc(){
        if (active_item==0){
            if (combobox_list_active==0){
                MyLocate.inst.rg_id="-1";
                MyLocate.inst.ray_id="-1";
                MyLocate.inst.punkt_id="-1";
                MyLocate.inst.street_id="-1";
                norg=false;
                noray=false;
                nopunkt=false;
                nostreet=false;
            }else if (!MyLocate.inst.rg_id.equals((String)MyLocate.inst.get_v_rg_id().elementAt(combobox_list_active-1))){
                MyLocate.inst.set_selected_rg_id((String)MyLocate.inst.get_v_rg_id().elementAt(combobox_list_active-1));
                MyLocate.inst.set_selected_rg_name((String)combobox_list.elementAt(combobox_list_active));
                MyLocate.inst.ray_id="-1";
                MyLocate.inst.punkt_id="-1";
                MyLocate.inst.street_id="-1";
                noray=false;
                nopunkt=false;
                nostreet=false;
            }
        }else if (active_item==1){
            if (combobox_list_active==0){
                MyLocate.inst.ray_id="-1";
                MyLocate.inst.punkt_id="-1";
                MyLocate.inst.street_id="-1";
                noray=false;
                nopunkt=false;
                nostreet=false;
            }else if (!MyLocate.inst.ray_id.equals((String)MyLocate.inst.get_v_ray_id().elementAt(combobox_list_active-1))){
                MyLocate.inst.set_selected_ray_id((String)MyLocate.inst.get_v_ray_id().elementAt(combobox_list_active-1));
                MyLocate.inst.set_selected_ray_name((String)combobox_list.elementAt(combobox_list_active));
                MyLocate.inst.punkt_id="-1";
                MyLocate.inst.street_id="-1";
                nopunkt=false;
                nostreet=false;
            }
        }else if (active_item==2){
            if (combobox_list_active==0){
                MyLocate.inst.punkt_id="-1";
                MyLocate.inst.street_id="-1";
                nopunkt=false;
                nostreet=false;
            }else if (!MyLocate.inst.punkt_id.equals((String)MyLocate.inst.get_v_punkt_id().elementAt(combobox_list_active-1))){
                MyLocate.inst.set_selected_punkt_id((String)MyLocate.inst.get_v_punkt_id().elementAt(combobox_list_active-1));
                MyLocate.inst.set_selected_punkt_name((String)combobox_list.elementAt(combobox_list_active));
                MyLocate.inst.street_id="-1";
                nostreet=false;
            }
        }else if (active_item==3){
            if (combobox_list_active==0){
                MyLocate.inst.street_id="-1";
                nostreet=false;
            }else {
                MyLocate.inst.set_selected_street_id((String)MyLocate.inst.get_v_street_id().elementAt(combobox_list_active-1));
                MyLocate.inst.set_selected_street_name((String)combobox_list.elementAt(combobox_list_active));
            }
        }
    }

    public void loadlist(Vector list){
         combobox_list=new Vector();
         int c=list.size();
         if (c>0){
             combobox_list.addElement("�� �������");
             for(int i=0;i<c;i++) combobox_list.addElement(list.elementAt(i));
         }
        combobox_list_size=combobox_list.size();
        if (active_item==0) {
            loadrg=false;
            norg=false;
            if (list.isEmpty()) {
                norg=true;
                MyLocate.inst.rg_id="-1";
            }
        }
        else if (active_item==1) {
            loadray=false;
            noray=false;
            if (list.isEmpty()) {
                noray=true;
                MyLocate.inst.ray_id="-1";
            }
        }
        else if (active_item==2) {
            loadpunkt=false;
            nopunkt=false;
            if (list.isEmpty()) {
                nopunkt=true;
                MyLocate.inst.punkt_id="-1";
            }
        }
        /*else if (active_item==3){
            loadstreet=false;
            nostreet=false;
            if (list.isEmpty()) {
                nostreet=true;
                MyLocate.inst.street_id="-1";
            }
        }*/
        if (!list.isEmpty()) {
            CG.initcomboscrol(-1);
            combobox_list_show=true;
        }
        ScreenCanvas.inst.repaint();
    }

    public void setActive(){

    }
}
