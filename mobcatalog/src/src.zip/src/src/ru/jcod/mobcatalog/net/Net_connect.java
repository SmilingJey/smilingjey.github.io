package ru.jcod.mobcatalog.net;

import ru.jcod.mobcatalog.ui.MyAlert;
import ru.jcod.mobcatalog.*;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import javax.microedition.io.*;
import javax.microedition.lcdui.Canvas;
import javax.microedition.lcdui.Display;
import ru.jcod.mobcatalog.ui.CG;
import ru.jcod.mobcatalog.ui.SConnect;
import ru.jcod.mobcatalog.ui.ScreenCanvas;

public class Net_connect implements Runnable {

    public static Net_connect inst;
    private StreamConnection socket;
    private InputStream in;
    private OutputStream out;
    private Reader r;
    private Writer w;
    private boolean connect;
    private int connect_count = 0;
    private int byteload = 0;
    private String must_send = "";

    public Net_connect() {
        inst = this;
    }

    public void run() {
        connect();
    }

    public void connect() {
        SConnect.inst.set_load(2);
        try {
            connect_count++;
            socket = null;
            CG.setFullScreenMode((Canvas) ScreenCanvas.inst, false);
            socket = (StreamConnection) (Connector.open("socket://84.53.193.9:5550", Connector.READ_WRITE));
            CG.setFullScreenMode((Canvas) ScreenCanvas.inst, true);
            SConnect.inst.set_load(3);
            out = socket.openOutputStream();
            in = socket.openInputStream();
            r = new Reader(in);
            w = new Writer(out);
            (new Thread(r)).start();
            (new Thread(w)).start();
            try {
                Thread.sleep(200);
            } catch (InterruptedException ex) {
                System.err.println("own:: Interrupted: " + ex.getMessage());
            }
            connect_count = 0;
            connect = true;
            SConnect.inst.set_load(4);
            send("<hello id=\"" + Config.inst.get_clientid() + "\"></hello>");
            try {
                Thread.sleep(100);
            } catch (InterruptedException ex) {
                System.err.println("own:: Interrupted: " + ex.getMessage());
            }
            if (must_send != null && !must_send.equals("")) {
                send(must_send);
                must_send = "";
            }
        } catch (IOException e) {
            if (connect_count < 3) {
                System.out.println("can not connect - reconect");
                connect = false;
                connect();
            } else {
                System.out.println("no connect :(");
                connect_count = 0;
                //MyAlert da = new MyAlert("�������� ������������ � �������: " + e.getMessage());
                //Display.getDisplay(MobileCatalog.inst).setCurrent(da);
            }
        }
        SConnect.inst.set_load(6);
    }

    public void disconnect() {
        connect = false;
        try {
            if (in != null) {
                in.close();
                in = null;
            }
            if (in != null) {
                in.close();
                in = null;
            }
            if (socket != null) {
                socket.close();
                socket = null;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    synchronized void notify_this() {
        this.notify();
    }

    public void send(String mess) {
        System.out.println("send " + mess);
        if (connect) {
            w.send = mess;
            synchronized (w) {
                w.notify();
            }
        } else {
            //must_send = mess;
            //connect();
        }
    }

    public boolean connect_on() {
        return (connect && r != null && w != null);
    }

    public int get_byteload() {
        return byteload;
    }

    public String get_loadkb() {
        return Integer.toString(byteload / 1024);
    }

    public void set_loadb(int b) {
        byteload += b;
    }
}
