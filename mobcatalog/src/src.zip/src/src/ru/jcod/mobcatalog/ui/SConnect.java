package ru.jcod.mobcatalog.ui;

import javax.microedition.lcdui.Canvas;
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.CommandListener;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.Font;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;
import ru.jcod.mobcatalog.Config;
import ru.jcod.mobcatalog.MobileCatalog;

public class SConnect extends Canvas  implements CommandListener {

    public static SConnect inst;
    public String str="";
    private Image img;
    private int x=0,y=0,w,h,hf;
    private String conns;
    private Font f=Font.getFont(Font.FACE_PROPORTIONAL,Font.STYLE_PLAIN,Font.SIZE_SMALL);
    private int load=0;
    private Command cOK,cExit;

    public SConnect(){
       inst = this;
       cOK=new Command("�����", Command.OK, 1);
       addCommand(cOK);
       cExit=new Command("�����", Command.EXIT, 1);
       addCommand(cExit);
       setCommandListener(this);
        try{
            img=Image.createImage("/res/logo.png");
        } catch(java.io.IOException e){}
    }

    public void set_load(int i){
        load=i;
    }

    public void paint(Graphics g) {
       hf=f.getHeight();
       w=getWidth();
       h=getHeight();
       x=(w-img.getWidth())/2;
       y=(h-img.getHeight()-16-hf*6)/2;
       if (load==6) {
           conns=" - ok";
       } else{
           conns=CG.inst.dots;
       }
       g.setColor(0xffffff);
       g.fillRect(0, 0, w, h);
       g.drawImage(img,w/2,y,Graphics.HCENTER | Graphics.TOP);
       g.setColor(0x000000);
       g.setFont(f);
       g.drawString("� ��� ������: " + Config.client,x,y+img.getHeight()+5, Graphics.LEFT | Graphics.TOP);
       if (!Config.server_client.equals(""))
       g.drawString("��������� ������: " + Config.server_client,x,y+img.getHeight()+5+hf, Graphics.LEFT | Graphics.TOP);
       g.drawString("������������ �������:",x,y+img.getHeight()+5+hf+hf, Graphics.LEFT | Graphics.TOP);
       g.drawString("�� ��� �����: "+Config.inst.get_loadkb()+"kb.", x,y+img.getHeight()+5+hf+hf+hf, Graphics.LEFT | Graphics.TOP);
       CG.p_progressbar(g,x+2,y+img.getHeight()+8+hf*4,img.getWidth()-4,hf,load,6," ", false);
       g.setColor(0x111111);
       g.drawString("����������� "+conns,(w-f.stringWidth("����������� "))/2,y+img.getHeight()+9+hf*4, Graphics.LEFT | Graphics.TOP);
       g.setColor(0x0000ff);
       g.drawString("http://mobcatalog.ru",w/2,y+img.getHeight()+11+hf*5, Graphics.HCENTER | Graphics.TOP);
   }

   public void commandAction(Command command, Displayable displayable) {
        if (command.equals(cOK)) {
            if (load>3) {
                MobileCatalog.inst.set_screancanvas();
            }
        }else if (command.equals(cExit)) MobileCatalog.quitApp();
    }
}
