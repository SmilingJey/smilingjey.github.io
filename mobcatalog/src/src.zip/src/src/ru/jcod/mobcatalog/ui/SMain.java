package ru.jcod.mobcatalog.ui;

import ru.jcod.mobcatalog.data.MyData;
import ru.jcod.mobcatalog.data.MyLocate;
import ru.jcod.mobcatalog.*;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Graphics;

public class SMain implements ICanvas{

    static SMain inst;
    private String title="������� ����";
    private String[] menu={"����� � �����������","����������",
    "��������","�����","��������������","���������","� ���������","�����"};
    private int h0,hh,fullh,menu_width,yadd,x,fw,active_menu_item;
    private boolean menu_scroll;


    public SMain(){
        inst = this;
    }

    public void paint(Graphics g) {
       p_menu(g);
       CG.p_beg_string(g);
       CG.p_title(g,title,false);
       CG.p_button(g, null, null, false, false, 0, "�����", "�������");
    }

    public void p_menu(Graphics g){
        g.setClip(0, h0, CG.inst.width, fullh);
        for(int i=0;i<menu.length;i++){
            if (i==active_menu_item) g.setColor(CG.inst.active_item_background);
            else g.setColor(CG.inst.menu_item_background);
            g.fillRect(0, h0+i*hh-yadd, menu_width,hh);
            g.setFont(CG.inst.menu_font);
            if (i==active_menu_item) g.setColor(CG.inst.active_textcolor);
            else g.setColor(CG.inst.menu_textcolor);
            fw=CG.inst.menu_font.stringWidth(menu[i]);
            x=5;
            if (CG.inst.width<fw){
                if (i==active_menu_item){
                    CG.inst.text_width=fw;
                    x=CG.inst.text_x;
                } 
                g.drawString(menu[i],x,h0+i*hh+2-yadd,Graphics.LEFT | Graphics.TOP);
            }else
                g.drawString(menu[i],(int)(CG.inst.width/2),h0+i*hh+2-yadd,Graphics.HCENTER | Graphics.TOP);
            g.setColor(CG.inst.menu_item_border);
            g.drawRect(0, h0+i*hh-yadd, menu_width-1,hh);
        }

       if (menu_scroll){
           g.setColor(CG.inst.scroll_color);
           g.fillRect(CG.inst.width-CG.inst.scroll_width, h0, CG.inst.scroll_width,fullh);
           g.setColor(CG.inst.scroll_pols);
           int hpp=(int)(fullh/(menu.length));if (hpp<2) hpp=3;
           g.fillRect(CG.inst.width-CG.inst.scroll_width, h0+active_menu_item*hpp, CG.inst.scroll_width, hpp);
        }
        g.setClip(0, 0, CG.inst.width, CG.inst.height);
    }

    public void keyPressed(int key){
       if (key== 1 || key==2)       {
            if (active_menu_item!=0) active_menu_item--;
            else active_menu_item=menu.length-1;
       }else if (key == 6 || key==5)       {
            if (active_menu_item!=menu.length-1) active_menu_item++;
            else active_menu_item=0;
       }else if (key == -6){
           MobileCatalog.quitApp();
       }else if (key == -8 || key == -7){
            if (active_menu_item==0) {
                int city=Integer.parseInt(MyLocate.inst.get_city());
                if (city!=-1){
                    SCat.inst.load_data=true;
                    SCat.inst.data_type=0;
                    MyData.inst.load_cat(city);
                    CG.inst.text_x=5;
                    ScreenCanvas.inst.set_current_canvas(SCat.inst);
                }else{
                    MyAlert da=new MyAlert("���������� ������� ��������������");
                    Display.getDisplay(MobileCatalog.inst).setCurrent(da);
                }
            }else if (active_menu_item==3) {
                ScreenCanvas.inst.set_current_canvas(SSearch.inst);
            }else if (active_menu_item==1) {
                int city=Integer.parseInt(MyLocate.inst.get_city());
                if (city!=-1){
                    ScreenCanvas.inst.set_current_canvas(SObiav.inst);
                }else{
                    MyAlert da=new MyAlert("���������� ������� ��������������");
                    Display.getDisplay(MobileCatalog.inst).setCurrent(da);
                }
            }else if (active_menu_item==6) {
                ScreenCanvas.inst.set_current_canvas(SAbout.inst);
            }else if (active_menu_item==7) {
                MobileCatalog.quitApp();
            }else if (active_menu_item==4){
                ScreenCanvas.inst.set_current_canvas(SLocate.inst);
            }else if (active_menu_item==5){
                Display.getDisplay(MobileCatalog.inst).setCurrent(Config.inst.getForm());
            }else if (active_menu_item==2){
                int city=Integer.parseInt(MyLocate.inst.get_city());
                if (city!=-1){
                    SCat.inst.load_data=true;
                    SCat.inst.data_type=1;
                    MyData.inst.load_prof();
                    ScreenCanvas.inst.set_current_canvas(SCat.inst);
                }else{
                    MyAlert da=new MyAlert("���������� ������� ��������������");
                    Display.getDisplay(MobileCatalog.inst).setCurrent(da);
                }
            }
       }

       if ((active_menu_item+1)*hh>fullh) yadd=(active_menu_item+1)*hh-fullh+1;
       else yadd=0;
       CG.inst.text_x=5;
    }

    public void setActive(){
        h0=CG.inst.beg_string_font.getHeight()+ CG.inst.title_string_font.getHeight()+6;
        hh=(CG.inst.menu_height==0)?CG.inst.menu_font.getHeight()+3:CG.inst.menu_height;
        fullh=CG.inst.height-h0-CG.inst.button_font.getHeight()-3;
        menu_scroll=(hh*menu.length>fullh);
        menu_width=CG.inst.width;
        if (menu_scroll) menu_width=CG.inst.width-CG.inst.scroll_width;
        yadd=0;
    }
}
