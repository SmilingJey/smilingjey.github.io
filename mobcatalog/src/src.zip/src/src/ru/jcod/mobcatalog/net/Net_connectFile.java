package ru.jcod.mobcatalog.net;

import ru.jcod.mobcatalog.ui.MyAlert;
import ru.jcod.mobcatalog.*;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import javax.microedition.io.*;
import javax.microedition.lcdui.Canvas;
import javax.microedition.lcdui.Display;
import ru.jcod.mobcatalog.ui.CG;
import ru.jcod.mobcatalog.ui.ScreenCanvas;

public class Net_connectFile implements Runnable{

    public static Net_connectFile inst;
    public int type=0;
	public InputStream in;
    private StreamConnection socket;
	private OutputStream out;
    private ReaderFile r;
	private Writer w;
	private boolean connect;
    private long byteload=0;
    private String mess;

	public Net_connectFile(String mess,int type){
        inst=this;
        this.type=type;
        this.mess=mess;
	}

    public void run(){
        connect();
	}

    public void connect(){
		try{
            CG.setFullScreenMode((Canvas)ScreenCanvas.inst,false);
			socket = (StreamConnection)(Connector.open("socket://84.53.193.9:5550",Connector.READ_WRITE));
            CG.setFullScreenMode((Canvas)ScreenCanvas.inst,true);
            out=socket.openOutputStream();
            in=socket.openInputStream();
			r=new ReaderFile(this);
			w=new Writer(out);
            (new Thread(r)).start();
            (new Thread(w)).start();
            try {
                Thread.sleep(200);
            } catch (InterruptedException ex) {
                System.err.println("own:: Interrupted: "+ex.getMessage());
            }
			connect=true;
            send(mess);
        }catch(IOException e){
            connect=false;
            MyAlert da=new MyAlert("�������� ������������ � �������: "+e.getMessage());
            Display.getDisplay(MobileCatalog.inst).setCurrent(da);
        }
    }

	public void disconnect(){
		connect=false;
        try{
            if( in != null ){
                in.close();
                in = null;
            }
            if( in != null ){
                in.close();
                in = null;
            }
            if( socket != null ){
                socket.close();
                socket = null;
            }
        }
        catch(IOException e) {
            e.printStackTrace();
        }
	}

	synchronized void notify_this() {
		this.notify();
	}

	public void send(String mess){
        System.out.println("send "+mess);
        w.send=mess;
        synchronized(w){
            w.notify();
        }
	}

    public int file_get(){
        if (r!=null) return r.file_get;
        return 0;
    }

    public int file_size(){
        if (r!=null) return r.file_size;
        return 0;
    }
}
