package ru.jcod.mobcatalog.ui;

import ru.jcod.mobcatalog.data.MyData;
import ru.jcod.mobcatalog.data.MyLocate;
import javax.microedition.lcdui.Graphics;

public class SSearch implements ICanvas{

    public static SSearch inst;
    public String search_text="������� �����";
    private String title="�����";
    private String leftbutton[]={"�����"};
    private String rightbutton[]={"��.����"};
    private boolean show_leftbutton=false;
    private boolean show_rightbutton=false;
    private int active_button=0;
    private int active_menu_item=0;
    public int radiobutton_select=0;
    private int x,y,w,h;

    public SSearch(){
        inst = this;
    }

    public void paint(Graphics g) {
       CG.p_beg_string(g);
       CG.p_title(g,title,false);
       CG.p_textfield(g,x,y,w,h,active_menu_item==0,search_text);
       CG.p_radiobutton(g,x-5,y+h+6,"����� �� ������",radiobutton_select==0,active_menu_item==1);
       CG.p_radiobutton(g,x-5,y+h+CG.inst.menu_font.getHeight()+9,"����� �� ���������",radiobutton_select==1,active_menu_item==2);
       CG.p_radiobutton(g,x-5,y+h+2*CG.inst.menu_font.getHeight()+12,"����� �� �����������",radiobutton_select==2,active_menu_item==3);
       CG.p_button(g, leftbutton, null, show_leftbutton, false, active_button, "��.����", "�����");
    }

    public void keyPressed( int key){
        if (key == 1)       {
            if (show_leftbutton || show_rightbutton){
                if (active_button!=(show_leftbutton?leftbutton.length-1:rightbutton.length-1)) active_button++;
                else active_button=0;
            }else{
                if (active_menu_item!=0) active_menu_item--;
                else active_menu_item=3;
            }
       }else if (key == 6){
            if (show_leftbutton || show_rightbutton){
                if (active_button!=0) active_button--;
                else active_button=show_leftbutton?leftbutton.length-1:rightbutton.length-1;
            }else{
                if (active_menu_item!=3) active_menu_item++;
                else active_menu_item=0;
            }
       }else if (key == -6){
           if (leftbutton.length>1){
               show_leftbutton=!show_leftbutton;
               active_button=0;
           }else{
               ScreenCanvas.inst.set_current_canvas(SMain.inst);
           }
       }else if (key == -7){
           if (rightbutton.length>1){
               show_rightbutton=!show_rightbutton;
               active_button=0;
           }else{
               if (!search_text.equals("")){
                      if (radiobutton_select==0){
                            SNames.inst.load_data=true;
                            SNames.inst.search=true;
                            MyData.inst.load_search(Integer.parseInt(MyLocate.inst.get_city())
                                    , search_text, "nameSrch", 1,"names_list");
                            ScreenCanvas.inst.set_current_canvas(SNames.inst);
                      }else if (radiobutton_select==1){
                            SVac.inst.load_data=true;
                            SVac.inst.search=true;
                            MyData.inst.load_search(Integer.parseInt(MyLocate.inst.get_city())
                                    , search_text, "vacSrch", 1,"vac_list");
                            ScreenCanvas.inst.set_current_canvas(SVac.inst);
                      }else if (radiobutton_select==2){
                            SObiav_list.inst.load_data=true;
                            SObiav_list.inst.search=true;
                            MyData.inst.load_search(Integer.parseInt(MyLocate.inst.get_city())
                                    , search_text, "ann", 1,"ann_list");
                            ScreenCanvas.inst.set_current_canvas(SObiav_list.inst);
                      }
                }
           }
       }else if (key == 2){

       }else if (key == 5){

       }else if (key == -8){
           if(show_leftbutton){
               if (active_button==0){

               }else if (active_button==1){

               }else if (active_button==2){
                   ScreenCanvas.inst.set_current_canvas(SLocate.inst);
               }
               show_leftbutton=false;
               active_button=0;
           }else if(show_rightbutton){
               if (active_button==0){

               }
               show_rightbutton=false;
               active_button=0;
           } else{
               if (active_menu_item==0){
                    Search_inputbox.inst.show(this,"������� ����� ��� ������",null);
               }else{
                    radiobutton_select=active_menu_item-1;
               }
           }
       }
    }

    public void setActive(){
       x=10;
       y=CG.inst.beg_string_font.getHeight()+CG.inst.title_string_font.getHeight()+10;
       w=CG.inst.width-20;
       h=CG.inst.combobox_font.getHeight()+4;
    }
}
