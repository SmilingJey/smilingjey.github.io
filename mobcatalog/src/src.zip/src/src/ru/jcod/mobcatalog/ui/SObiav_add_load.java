package ru.jcod.mobcatalog.ui;

import javax.microedition.lcdui.Graphics;

public class SObiav_add_load implements ICanvas{

    public static SObiav_add_load inst;

    private MultiLineText MLT;
    private boolean isFirstRun=true; 
    String leftbutton[]={"�����"};
    String rightbutton[]={"��.����"};
    boolean show_leftbutton=false;
    boolean show_rightbutton=false;
    int active_button=0;
    public boolean load_data=false;
    public int active_page=0;
    String title="�������� ����������";
    String text="";

    public SObiav_add_load(){
        inst = this;
    }

    public void paint(Graphics g) {
       CG.p_beg_string(g);
       CG.p_title(g,title,false);
       if (load_data){
            g.setColor(CG.inst.text_textcolor);
            g.setFont(CG.inst.get_text_font());
            g.drawString("�������� "+CG.inst.dots, 2, CG.inst.beg_string_font.getHeight()+
                    CG.inst.title_string_font.getHeight()+10, Graphics.LEFT | Graphics.TOP);
       }
       else p_text(g);
       CG.p_button(g, leftbutton, rightbutton, show_leftbutton, show_rightbutton, active_button,"�����","��.����");
    }

    public void p_text(Graphics g){
        if (isFirstRun==true){
            MLT = new MultiLineText();
            int hh=CG.inst.beg_string_font.getHeight()+ CG.inst.title_string_font.getHeight()+6;
            MLT.SetTextPar(1, hh, CG.inst.width-1,CG.inst.height-hh-CG.inst.button_font.getHeight()-3,10,
                    CG.inst.text_FontSize,CG.inst.text_FontStyle,CG.inst.text_FontType,g,
                    text,true);
            isFirstRun=false;
        }
       g.setColor(CG.inst.text_textcolor);
       MLT.DrawMultStr();
    }

    public void keyPressed(int key){
       if (key == 1)       {
            MLT.MoveUp();
       }else if (key == 6){
            MLT.MoveDown();
       }else if (key == -6){
            SObiav_add.inst.clear();
            ScreenCanvas.inst.set_current_canvas(SObiav_add.inst);
       }else if (key == -7){
            ScreenCanvas.inst.set_current_canvas(SMain.inst);
       }else if (key == 2){

       }else if (key == 5){

       }else if (key == -8){

       }
    }

    public void load_data(String text){
        load_data=false;
        this.text=text;
        isFirstRun=true;
        ScreenCanvas.inst.repaint();
    }

    public void setActive(){

    }
}
