package ru.jcod.mobcatalog.net;

import java.io.IOException;
import java.io.OutputStream;
import javax.microedition.lcdui.Display;
import ru.jcod.mobcatalog.MobileCatalog;
import ru.jcod.mobcatalog.ui.MyAlert;

public class Writer implements Runnable{
	OutputStream out;
	String send="";
	public boolean stop=false;

	public Writer(OutputStream out){
		this.out = out;
	}

	public void run(){
		try {
			while(!stop){
                synchronized(this){
                    try{
                        this.wait();
                    }catch (InterruptedException e){
                        e.printStackTrace();
                    }
				}
				out.write(send.getBytes());
                out.flush();
			}
			out.close();
		}catch(IOException e){
			Net_connect.inst.disconnect();
            MyAlert da=new MyAlert("��������� ����� ����������, ������� ������ �����������: "+e.getMessage());
            Display.getDisplay(MobileCatalog.inst).setCurrent(da);
            Net_connect.inst.connect();
		}
	}

	synchronized void notify_this() {
		this.notify();
	}
}
